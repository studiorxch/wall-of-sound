(function (global) {
  "use strict";
  var SBE = (global.SBE = global.SBE || {});

  // ── MapboxViewportRuntime (0518E_WOS_MapboxViewport_v1.0.0) ───────────────
  // Singleton spatial layer. Manages the Mapbox GL JS map instance, coordinate
  // projection, camera synchronization, and style switching.
  //
  // The map renders in #mapbox-viewport beneath the WOS canvas.
  // All geographic coordinate conversion routes through this runtime.

  // ── Access token — replace with your Mapbox public token ─────────────────
  var ACCESS_TOKEN =
    "pk.eyJ1Ijoic3R1ZGlvcmljaCIsImEiOiJjbTNic2IyNzgxMGtxMmlvaHkyc3Z4NHFtIn0.VW7d_rhzopYeytP-crP4BQ";

  // ── Map styles ────────────────────────────────────────────────────────────
  var STYLES = {
    operator: "mapbox://styles/mapbox/dark-v11",
    presentation: "mapbox://styles/richielau/cm3goyx23003901qkb60ff29p",
  };

  // ── Default camera — Brooklyn, NY ─────────────────────────────────────────
  var DEFAULT_CAMERA = {
    center: [-73.9442, 40.6782],
    zoom: 13,
    bearing: 0,
    pitch: 0,
  };

  var _map = null;
  var _container = null;
  var _presentationMode = false;
  var _ready = false;
  var _readyCallbacks = [];

  // ── Lifecycle ──────────────────────────────────────────────────────────────
  function init(containerEl) {
    if (_map) return;
    if (!global.mapboxgl) {
      console.error("[MapboxViewportRuntime] mapboxgl not loaded");
      return;
    }
    if (ACCESS_TOKEN.indexOf("REPLACE") !== -1) {
      console.warn(
        "[MapboxViewportRuntime] Mapbox access token not set — map will not load",
      );
    }

    _container = containerEl;
    global.mapboxgl.accessToken = ACCESS_TOKEN;

    _map = new global.mapboxgl.Map({
      container: containerEl,
      style: STYLES.operator,
      center: DEFAULT_CAMERA.center,
      zoom: DEFAULT_CAMERA.zoom,
      bearing: DEFAULT_CAMERA.bearing,
      pitch: DEFAULT_CAMERA.pitch,
      antialias: true,
      attributionControl: false,
    });

    _map.on("load", function () {
      _ready = true;
      _readyCallbacks.forEach(function (fn) {
        try {
          fn();
        } catch (e) {}
      });
      _readyCallbacks = [];
      if (SBE.WorkspaceEventBus) {
        SBE.WorkspaceEventBus.emit("map:ready", {
          source: "MapboxViewportRuntime",
          timestamp: performance.now(),
        });
      }
      console.log("[MapboxViewportRuntime] map ready");
    });

    _map.on("error", function (e) {
      console.error(
        "[MapboxViewportRuntime] map error:",
        e.error && e.error.message,
      );
    });

    // Forward camera move events to event bus
    _map.on("move", function () {
      if (!SBE.WorkspaceEventBus) return;
      SBE.WorkspaceEventBus.emit("map:cameraMoved", {
        source: "MapboxViewportRuntime",
        timestamp: performance.now(),
      });
    });
    _map.on("moveend", function () {
      if (!SBE.WorkspaceEventBus) return;
      SBE.WorkspaceEventBus.emit("map:cameraChanged", {
        source: "MapboxViewportRuntime",
        timestamp: performance.now(),
        camera: getCamera(),
      });
    });
  }

  function destroy() {
    if (_map) {
      _map.remove();
      _map = null;
      _ready = false;
      _container = null;
    }
  }

  function resize() {
    if (_map) _map.resize();
  }

  function onReady(fn) {
    if (_ready) {
      fn();
      return;
    }
    _readyCallbacks.push(fn);
  }

  // ── Projection ─────────────────────────────────────────────────────────────
  // project([lng, lat]) → {x, y}  screen pixel coordinates
  function project(lngLat) {
    if (!_map || !_ready) return { x: 0, y: 0 };
    var pt = _map.project(lngLat);
    return { x: Math.round(pt.x), y: Math.round(pt.y) };
  }

  // unproject([x, y]) → {lng, lat}  geographic coordinates
  function unproject(point) {
    if (!_map || !_ready) return { lng: 0, lat: 0 };
    var ll = _map.unproject(point);
    return { lng: ll.lng, lat: ll.lat };
  }

  // ── Camera ─────────────────────────────────────────────────────────────────
  function setCamera(state) {
    if (!_map) return;
    _map.jumpTo({
      center: state.center || DEFAULT_CAMERA.center,
      zoom: state.zoom !== undefined ? state.zoom : DEFAULT_CAMERA.zoom,
      bearing:
        state.bearing !== undefined ? state.bearing : DEFAULT_CAMERA.bearing,
      pitch: state.pitch !== undefined ? state.pitch : DEFAULT_CAMERA.pitch,
    });
  }

  function getCamera() {
    if (!_map) return Object.assign({}, DEFAULT_CAMERA);
    var c = _map.getCenter();
    return {
      center: [c.lng, c.lat],
      zoom: _map.getZoom(),
      bearing: _map.getBearing(),
      pitch: _map.getPitch(),
    };
  }

  function flyTo(target) {
    if (!_map) return;
    _map.flyTo({
      center: target.center,
      zoom: target.zoom !== undefined ? target.zoom : _map.getZoom(),
      bearing:
        target.bearing !== undefined ? target.bearing : _map.getBearing(),
      pitch: target.pitch !== undefined ? target.pitch : _map.getPitch(),
      speed: target.speed || 1.2,
      curve: target.curve || 1.42,
      duration: target.duration,
    });
  }

  function fitBounds(bounds, opts) {
    if (!_map) return;
    _map.fitBounds(bounds, opts || { padding: 60 });
  }

  // ── Style / presentation mode ──────────────────────────────────────────────
  function setPresentationMode(enabled) {
    _presentationMode = !!enabled;
    if (!_map) return;
    var style = enabled ? STYLES.presentation : STYLES.operator;
    _map.setStyle(style);
    if (SBE.WorkspaceEventBus) {
      SBE.WorkspaceEventBus.emit("map:styleChanged", {
        source: "MapboxViewportRuntime",
        timestamp: performance.now(),
        mode: enabled ? "presentation" : "operator",
        style: style,
      });
    }
  }

  function isPresentationMode() {
    return _presentationMode;
  }
  function isReady() {
    return _ready;
  }
  function getMap() {
    return _map;
  }

  // ── Canvas overlays ────────────────────────────────────────────────────────
  // These are called by the runtime viewport router for canvas-layer drawing
  // that must be spatially aligned with the map (e.g. route lines, waypoints).

  function renderOperatorOverlay(ctx, options) {
    if (SBE.MapboxOperatorRenderer) {
      SBE.MapboxOperatorRenderer.render(ctx, options);
    }
  }

  function renderPresentationLayer(ctx, options) {
    if (SBE.MapboxPresentationRenderer) {
      SBE.MapboxPresentationRenderer.render(ctx, options);
    }
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  SBE.MapboxViewportRuntime = {
    init: init,
    destroy: destroy,
    resize: resize,
    onReady: onReady,

    project: project,
    unproject: unproject,

    setCamera: setCamera,
    getCamera: getCamera,
    flyTo: flyTo,
    fitBounds: fitBounds,

    setPresentationMode: setPresentationMode,
    isPresentationMode: isPresentationMode,

    isReady: isReady,
    getMap: getMap,

    renderOperatorOverlay: renderOperatorOverlay,
    renderPresentationLayer: renderPresentationLayer,
  };
})(window);
