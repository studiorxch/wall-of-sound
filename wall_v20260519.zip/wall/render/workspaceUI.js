(function initWorkspaceUI(global) {
  "use strict";
  var SBE = (global.SBE = global.SBE || {});

  // ── Workspace UI (0518_WOS_WorkspaceArchitecture_v1.0.0) ─────────────────
  //
  // DOM manager. Injects and maintains three chrome surfaces:
  //
  //   #ws-tab-bar       — flex child, order:-1, inside .canvas-area
  //   #ws-sidebar-nav   — prepended to #left-rail, above existing buttons
  //   #ws-lower-panel   — flex child, inside .canvas-area, below canvas-wrap
  //
  // Responds to SBE.Workspace events: tabsChanged, activeDocumentChanged,
  // sidebarContextChanged. Never touches simulation state.

  // ── Sidebar nav definition (0520_WOS_WorldRuntimeArchitecture_v1.0.0) ───────
  // Sections mirror the canonical runtime hierarchy:
  //   WORLD → ZONES → SYSTEMS → VISUALIZATION → (utility)
  // Items with `section` render as non-interactive section labels.
  var NAV_ITEMS = [
    { section: "WORLD" },
    { ctx: "world",     icon: "◎", tooltip: "World" },
    { section: "ZONES" },
    { ctx: "zones",     icon: "⬡", tooltip: "Zones" },
    { section: "SYSTEMS" },
    { ctx: "routes",    icon: "⬡", tooltip: "Routes" },
    { ctx: "layers",    icon: "▤", tooltip: "Layers" },
    { ctx: "sequences", icon: "⋮⋮", tooltip: "Sequences" },
    { section: "VIZ" },
    { ctx: "assets",    icon: "◻", tooltip: "Assets" },
    { section: "—" },
    { ctx: "settings",  icon: "⚙", tooltip: "Settings" },
    { ctx: "help",      icon: "?",  tooltip: "Help" },
  ];

  // ── DOM refs ──────────────────────────────────────────────────────────────
  var _tabBar      = null;
  var _sidebarNav  = null;
  var _lowerPanel  = null;
  var _navBtns     = {};   // ctx → button element

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    if (!SBE.Workspace) {
      console.warn("[WorkspaceUI] SBE.Workspace not available — skipping UI init");
      return;
    }

    // WorldRuntime is the authoritative world root — initialize before UI
    if (SBE.WorldRuntime) SBE.WorldRuntime.init();

    // World atmosphere systems — clock, weather, moon, calendar, atmosphere
    if (SBE.WorldAtmosphereSystem) SBE.WorldAtmosphereSystem.init();

    _buildMapboxViewport();
    _buildTabBar();
    _buildSidebarNav();
    _buildLowerPanel();

    // Mark canvas-area for padding overrides
    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) canvasArea.classList.add("ws-chrome-active");

    // Subscribe to workspace events via WorkspaceEventBus
    SBE.WorkspaceEventBus.on("workspace:surfacesChanged",      _onTabsChanged);
    SBE.WorkspaceEventBus.on("surface:opened",                 _onActiveDocChanged);
    SBE.WorkspaceEventBus.on("sidebar:changed",                _onSidebarContextChanged);
    SBE.WorkspaceEventBus.on("surface:saved",                  _updateLowerPanel);
    SBE.WorkspaceEventBus.on("surface:loaded",                 _updateLowerPanel);
    SBE.WorkspaceEventBus.on("workspace:interactionModeChanged", _updateLowerPanel);
    SBE.WorkspaceEventBus.on("world:zoneCreated",              _updateLowerPanel);
    SBE.WorkspaceEventBus.on("world:zoneDeleted",              _updateLowerPanel);
    SBE.WorkspaceEventBus.on("routes:changed",                 _updateLowerPanel);

    // Activate map for initial route document
    _syncMapToActiveDoc();

    // Initial render
    _onTabsChanged({ docs: SBE.Workspace.getAllSurfaces(), activeId: _getActiveId() });
    _onSidebarContextChanged({ context: SBE.Workspace.getSidebarContext() });
    _updateLowerPanel();

    console.log("[WorkspaceUI] initialized");
  }

  // ── Mapbox viewport injection ─────────────────────────────────────────────
  function _buildMapboxViewport() {
    var canvasArea = document.querySelector(".canvas-area");
    if (!canvasArea) {
      console.warn("[WorkspaceUI] .canvas-area not found — Mapbox viewport not injected");
      return;
    }
    if (document.getElementById("mapbox-viewport")) return; // idempotent

    var viewport = document.createElement("div");
    viewport.id = "mapbox-viewport";

    // Insert before canvas-wrap so canvas overlays the map
    var canvasWrap = document.getElementById("canvas-wrap");
    if (canvasWrap) {
      canvasArea.insertBefore(viewport, canvasWrap);
    } else {
      canvasArea.insertBefore(viewport, canvasArea.firstChild);
    }

    // Init Mapbox if available
    if (SBE.MapboxViewportRuntime) {
      SBE.MapboxViewportRuntime.init(viewport);
    }

    // Surface overlay canvas — drawing layer above route overlays
    _buildSurfaceOverlay(canvasArea);

    // Atmospheric HUD — glass world-state overlay
    if (SBE.WorldHUD) SBE.WorldHUD.init();

    // Geo camera controls — injected once alongside the viewport
    _buildGeoCameraControls(canvasArea);
  }

  // ── Surface overlay canvas ────────────────────────────────────────────────
  function _buildSurfaceOverlay(canvasArea) {
    if (document.getElementById("surface-overlay")) return; // idempotent

    var overlay = document.createElement("canvas");
    overlay.id = "surface-overlay";

    // Size to match canvas-area; will be kept in sync via resize observer
    var rect = canvasArea.getBoundingClientRect();
    overlay.width  = rect.width  > 0 ? Math.round(rect.width)  : 1;
    overlay.height = rect.height > 0 ? Math.round(rect.height) : 1;

    canvasArea.appendChild(overlay);

    // Initialise drawing runtime
    if (SBE.SurfaceDrawingRuntime) {
      SBE.SurfaceDrawingRuntime.init(overlay);
    }

    // Keep overlay canvas sized to canvas-area on resize
    if (typeof ResizeObserver !== "undefined") {
      var ro = new ResizeObserver(function () {
        if (SBE.SurfaceDrawingRuntime) SBE.SurfaceDrawingRuntime.syncCanvasSize();
      });
      ro.observe(canvasArea);
    }

    // Sync pointer-events and cursor with interaction mode
    SBE.WorkspaceEventBus.on("workspace:interactionModeChanged", function (evt) {
      var isDraw = evt.mode === "draw";
      overlay.style.pointerEvents = isDraw ? "auto" : "none";
      canvasArea.classList.toggle("ws-draw-mode", isDraw);
    });
  }

  // ── Geo camera controls overlay ───────────────────────────────────────────
  function _buildGeoCameraControls(canvasArea) {
    if (document.getElementById("ws-geo-controls")) return; // idempotent

    var bar = document.createElement("div");
    bar.id = "ws-geo-controls";

    function _btn(label, title, action) {
      var b = document.createElement("button");
      b.className = "ws-geo-btn";
      b.textContent = label;
      b.title = title;
      b.addEventListener("click", function(e) {
        e.stopPropagation();
        action();
      });
      return b;
    }

    function _map() {
      return SBE.MapboxViewportRuntime && SBE.MapboxViewportRuntime.getMap
        ? SBE.MapboxViewportRuntime.getMap() : null;
    }

    bar.appendChild(_btn("+", "Zoom in", function() {
      var m = _map(); if (m) m.zoomIn({ duration: 200 });
    }));
    bar.appendChild(_btn("−", "Zoom out", function() {
      var m = _map(); if (m) m.zoomOut({ duration: 200 });
    }));
    bar.appendChild(_btn("↑", "Reset bearing", function() {
      var m = _map(); if (m) m.resetNorth({ duration: 400 });
    }));
    bar.appendChild(_btn("⊡", "Fit active route", function() {
      // Try RouteInputSystem first, fall back to routePlanner runtime
      var routes = SBE.RouteInputSystem ? SBE.RouteInputSystem.getRoutes() : [];
      if (routes.length) {
        SBE.RouteInputSystem.fitRoute(routes[0].id);
        return;
      }
      var surf = SBE.Workspace && SBE.Workspace.getActiveSurface();
      var rt = surf && surf.runtime;
      var rtRoutes = rt && rt.routes;
      if (rtRoutes && rtRoutes.length) {
        var r = rtRoutes[0];
        var wps = r.waypoints || [];
        if (!wps.length) return;
        var m = _map();
        if (!m) return;
        var lngs = wps.map(function(w) { return w.longitude; });
        var lats = wps.map(function(w) { return w.latitude; });
        m.fitBounds([
          [Math.min.apply(null, lngs), Math.min.apply(null, lats)],
          [Math.max.apply(null, lngs), Math.max.apply(null, lats)]
        ], { padding: 80, duration: 600 });
      }
    }));

    // Draw mode toggle — switches workspace interaction mode to "draw"
    var drawBtn = _btn("✏", "Draw on map", function() {
      if (!SBE.Workspace) return;
      var next = SBE.Workspace.getInteractionMode() === "draw" ? "navigate" : "draw";
      // Exit route-edit mode on runtime before switching
      if (next === "draw") {
        var surf = SBE.Workspace.getActiveSurface();
        var rt = surf && surf.runtime;
        if (rt && rt.setMode && rt.mode !== "view") rt.setMode("view");
      }
      SBE.Workspace.setInteractionMode(next);
    });
    bar.appendChild(drawBtn);

    // Route edit mode toggle
    var editBtn = _btn("✎", "Toggle route edit mode", function() {
      var surf = SBE.Workspace && SBE.Workspace.getActiveSurface();
      var rt = surf && surf.runtime;
      if (!rt || !rt.setMode) return;
      var nextMode = (rt.mode === "view") ? "route-edit" : "view";
      rt.setMode(nextMode);
      // Sync workspace interaction mode
      if (SBE.Workspace) {
        SBE.Workspace.setInteractionMode(nextMode === "route-edit" ? "route-edit" : "navigate");
      }
    });
    bar.appendChild(editBtn);

    // Keep buttons in sync with workspace interaction mode
    if (SBE.WorkspaceEventBus) {
      SBE.WorkspaceEventBus.on("workspace:interactionModeChanged", function(evt) {
        drawBtn.classList.toggle("ws-geo-btn--active", evt.mode === "draw");
        drawBtn.title = evt.mode === "draw" ? "Exit draw mode" : "Draw on map";
        editBtn.classList.toggle("ws-geo-btn--active", evt.mode === "route-edit");
        editBtn.title = evt.mode === "route-edit" ? "Exit route edit" : "Toggle route edit mode";
      });
      SBE.WorkspaceEventBus.on("runtime:modeChanged", function(evt) {
        editBtn.classList.toggle("ws-geo-btn--active", evt.mode === "route-edit");
      });
    }

    canvasArea.appendChild(bar);
  }

  function _syncMapToActiveDoc() {
    var doc = SBE.Workspace && SBE.Workspace.getActiveSurface();
    var isGeo = doc && (doc.type === "route" || doc.type === "world");
    var canvasArea = document.querySelector(".canvas-area");
    var canvas    = document.getElementById("engine-canvas");

    if (canvasArea) {
      canvasArea.classList.toggle("ws-map-active", !!isGeo);
      canvasArea.classList.toggle("ws-geo-mode",   !!isGeo);
    }

    // Resize canvas to fill canvas-area so canvas pixels align with map CSS pixels.
    // Must run after CSS classes are applied (layout is synchronous here).
    if (isGeo && canvas && canvasArea) {
      requestAnimationFrame(function() {
        var rect = canvasArea.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
          canvas.width  = Math.round(rect.width);
          canvas.height = Math.round(rect.height);
        }
      });
    }
  }

  // ── Tab bar ───────────────────────────────────────────────────────────────
  function _buildTabBar() {
    _tabBar = document.createElement("div");
    _tabBar.id = "ws-tab-bar";

    // "New document" button at far right
    var addBtn = document.createElement("button");
    addBtn.className = "ws-tab-add";
    addBtn.title = "New surface";
    addBtn.textContent = "+";
    addBtn.addEventListener("click", _onAddDocument);
    _tabBar.appendChild(addBtn);

    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) {
      canvasArea.insertBefore(_tabBar, canvasArea.firstChild);
    } else {
      console.warn("[WorkspaceUI] .canvas-area not found — tab bar not injected");
    }
  }

  function _onTabsChanged(evt) {
    if (!_tabBar) return;
    var docs     = evt.docs || [];
    var activeId = evt.activeId || null;

    // Clear existing tabs (keep the add button)
    var addBtn = _tabBar.querySelector(".ws-tab-add");
    _tabBar.innerHTML = "";

    // Render tabs
    docs.forEach(function(doc) {
      var tab = _makeTabEl(doc, activeId === doc.id);
      _tabBar.appendChild(tab);
    });

    // Re-append add button
    if (addBtn) _tabBar.appendChild(addBtn);

    // Scroll active tab into view
    var activeTab = _tabBar.querySelector(".ws-tab--active");
    if (activeTab) activeTab.scrollIntoView({ inline: "nearest", block: "nearest" });

    _updateLowerPanel();
  }

  function _makeTabEl(doc, isActive) {
    var tab = document.createElement("button");
    tab.className = "ws-tab" + (isActive ? " ws-tab--active" : "") +
                    (doc.modified ? " ws-tab--modified" : "");
    tab.style.setProperty("--ws-tab-accent", doc.accent);
    tab.dataset.docId = doc.id;
    tab.title = doc.name;

    // Icon
    var icon = document.createElement("span");
    icon.className = "ws-tab-icon";
    icon.textContent = doc.icon;

    // Label
    var label = document.createElement("span");
    label.className = "ws-tab-label";
    label.textContent = doc.name;

    // Modified dot
    var dot = document.createElement("span");
    dot.className = "ws-tab-modified";

    // Close
    var closeBtn = document.createElement("button");
    closeBtn.className = "ws-tab-close";
    closeBtn.textContent = "×";
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      SBE.Workspace.closeDocument(doc.id);
    });

    tab.appendChild(icon);
    tab.appendChild(label);
    tab.appendChild(dot);
    tab.appendChild(closeBtn);

    tab.addEventListener("click", function(e) {
      // Don't activate if clicking close
      if (e.target === closeBtn) return;
      SBE.Workspace.openDocument(doc.id);
    });

    // Double-click to rename
    tab.addEventListener("dblclick", function(e) {
      if (e.target === closeBtn) return;
      _startRename(tab, doc);
    });

    return tab;
  }

  function _startRename(tabEl, doc) {
    var labelEl = tabEl.querySelector(".ws-tab-label");
    if (!labelEl) return;

    var input = document.createElement("input");
    input.type = "text";
    input.value = doc.name;
    input.style.cssText = [
      "background: rgba(255,255,255,0.08)",
      "border: 1px solid rgba(255,255,255,0.20)",
      "color: rgba(255,255,255,0.90)",
      "font-size: 11px",
      "font-family: inherit",
      "border-radius: 2px",
      "padding: 1px 4px",
      "outline: none",
      "width: 100px",
    ].join(";");

    tabEl.replaceChild(input, labelEl);
    input.select();

    function commit() {
      var val = input.value.trim();
      if (val) SBE.Workspace.renameDocument(doc.id, val);
      else     tabEl.replaceChild(labelEl, input);
    }
    input.addEventListener("keydown", function(e) {
      if (e.key === "Enter")  { e.preventDefault(); commit(); }
      if (e.key === "Escape") { tabEl.replaceChild(labelEl, input); }
    });
    input.addEventListener("blur", commit);
  }

  // ── Sidebar nav ───────────────────────────────────────────────────────────
  // Renders NAV_ITEMS with section header support.
  // Items with `section` property render as non-interactive dividers.
  function _buildSidebarNav() {
    _sidebarNav = document.createElement("div");
    _sidebarNav.id = "ws-sidebar-nav";

    NAV_ITEMS.forEach(function (item) {
      if (item.section !== undefined) {
        // Section divider label
        var label = document.createElement("div");
        label.className = "ws-nav-section";
        label.textContent = item.section;
        _sidebarNav.appendChild(label);
        return;
      }
      var btn = document.createElement("button");
      btn.className = "ws-nav-btn";
      btn.dataset.ctx = item.ctx;
      btn.dataset.tooltip = item.tooltip;
      btn.title = item.tooltip;
      btn.textContent = item.icon;
      btn.addEventListener("click", function () {
        SBE.Workspace.setSidebarContext(item.ctx);
      });
      _sidebarNav.appendChild(btn);
      _navBtns[item.ctx] = btn;
    });

    var leftRail = document.getElementById("left-rail");
    if (leftRail) {
      leftRail.insertBefore(_sidebarNav, leftRail.firstChild);
    } else {
      console.warn("[WorkspaceUI] #left-rail not found — sidebar nav not injected");
    }
  }

  function _onSidebarContextChanged(evt) {
    var ctx = evt.context;
    Object.keys(_navBtns).forEach(function (key) {
      _navBtns[key].classList.toggle("ws-nav-btn--active", key === ctx);
    });
  }

  // ── Lower panel ───────────────────────────────────────────────────────────
  function _buildLowerPanel() {
    _lowerPanel = document.createElement("div");
    _lowerPanel.id = "ws-lower-panel";

    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) {
      canvasArea.appendChild(_lowerPanel);
    } else {
      console.warn("[WorkspaceUI] .canvas-area not found — lower panel not injected");
    }
  }

  // ── Lower panel — world-centric status bar ────────────────────────────────
  // Spec (0520): Status only. NOT debug spam.
  //   active world · active tool · zones · route count · persistence · [ OP ] [ VIEW ] · [TEL]
  function _updateLowerPanel() {
    if (!_lowerPanel) return;
    _lowerPanel.innerHTML = "";

    var doc   = SBE.Workspace    ? SBE.Workspace.getActiveSurface()   : null;
    var world = SBE.WorldRuntime ? SBE.WorldRuntime.getActiveWorld()  : null;
    var imode = SBE.Workspace    ? SBE.Workspace.getInteractionMode() : "navigate";

    // ── Left: accent dot + world name ─────────────────────────────────────
    var dot = document.createElement("div");
    dot.className = "ws-lower-accent-dot";
    dot.style.setProperty("--ws-lower-accent", doc ? doc.accent : "#3dd8c5");
    _lowerPanel.appendChild(dot);

    var worldSpan = document.createElement("div");
    worldSpan.className = "ws-lower-world";
    worldSpan.textContent = world ? world.name : "—";
    worldSpan.title = world ? (world.description || world.name) : "";
    _lowerPanel.appendChild(worldSpan);

    // ── Center: status fields ──────────────────────────────────────────────
    var status = document.createElement("div");
    status.className = "ws-lower-status";

    // Active tool (interaction mode)
    _addStatusField(status, "tool", imode);

    // Zone count (world-aware)
    var zoneCount = SBE.WorldRuntime ? SBE.WorldRuntime.getZones().length : 0;
    _addStatusField(status, "zones", zoneCount > 0 ? String(zoneCount) : "—");

    // Route count
    var routeCount = SBE.RouteInputSystem ? SBE.RouteInputSystem.getRoutes().length : 0;
    _addStatusField(status, "routes", routeCount > 0 ? String(routeCount) : "—");

    // Surfaces
    var surfaceCount = SBE.Workspace ? SBE.Workspace.getAllSurfaces().length : 0;
    _addStatusField(status, "surfaces", String(surfaceCount));

    // Persistence
    if (doc) _addPersistenceIndicator(status, doc);

    // ── Right: [ OP ] [ VIEW ] mode toggle ────────────────────────────────
    if (SBE.RuntimeViewportRouter) {
      var modeToggle = document.createElement("div");
      modeToggle.className = "ws-mode-toggle";
      ["operator", "presentation"].forEach(function (m) {
        var btn = document.createElement("button");
        btn.className = "ws-mode-btn" + (SBE.RuntimeViewportRouter.getMode() === m ? " ws-mode-btn--active" : "");
        btn.textContent = m === "operator" ? "OP" : "VIEW";
        btn.title = m === "operator" ? "Operator mode" : "Presentation mode";
        btn.addEventListener("click", function () {
          SBE.RuntimeViewportRouter.setMode(m);
          _updateLowerPanel();
        });
        modeToggle.appendChild(btn);
      });
      status.appendChild(modeToggle);
    }

    // ── Telemetry toggle [TEL] ─────────────────────────────────────────────
    if (SBE.WorldRuntime) {
      var telBtn = document.createElement("button");
      var isTel  = SBE.WorldRuntime.isTelemetryEnabled();
      telBtn.className = "ws-mode-btn" + (isTel ? " ws-mode-btn--active" : "");
      telBtn.textContent = "TEL";
      telBtn.title = isTel ? "Hide telemetry" : "Show telemetry";
      telBtn.addEventListener("click", function () {
        SBE.WorldRuntime.toggleTelemetry();
        _updateLowerPanel();
      });
      status.appendChild(telBtn);
    }

    _lowerPanel.appendChild(status);
  }

  function _addPersistenceIndicator(container, doc) {
    if (!SBE.SurfacePersistence) return;
    var hasSaved = SBE.SurfacePersistence.hasSaved(doc.surfaceId || doc.id);
    var label, cls;
    if (!hasSaved) {
      label = "● LOCAL"; cls = "ws-persist--local";
    } else if (doc.modified) {
      label = "● MODIFIED"; cls = "ws-persist--modified";
    } else {
      label = "● SAVED"; cls = "ws-persist--saved";
    }

    var el = document.createElement("div");
    el.className = "ws-persist-indicator " + cls;
    el.textContent = label;
    el.title = hasSaved ? "Saved to localStorage" : "Not yet saved — click to save";
    el.style.cursor = "pointer";
    el.addEventListener("click", function () {
      if (SBE.Workspace) {
        SBE.Workspace.saveSurface(doc.id);
        _updateLowerPanel();
      }
    });
    container.appendChild(el);
  }

  function _addStatusField(container, key, value) {
    var field = document.createElement("div");
    field.className = "ws-lower-field";
    field.innerHTML = key + " <span class=\"ws-lower-value\">" + _esc(value) + "</span>";
    container.appendChild(field);
  }

  function _esc(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // ── Event handlers ────────────────────────────────────────────────────────
  function _onActiveDocChanged() {
    _syncMapToActiveDoc();
    _updateLowerPanel();
  }

  function _onAddDocument() {
    // New surfaces always start as route surfaces — name defaults to "Surface N"
    var doc = SBE.Workspace.createSurface("route");
    SBE.Workspace.openSurface(doc.id);
  }

  function _getActiveId() {
    var doc = SBE.Workspace ? SBE.Workspace.getActiveSurface() : null;
    return doc ? doc.id : null;
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  SBE.WorkspaceUI = {
    init: init,
  };

})(window);
