// ── WorldSpaceVehicleDebug v1.0.0 ─────────────────────────────────────────────
// 0531J_WOS_WorldSpaceVehicleLayer_v1.0.0
// Status: prototype
// Classification: debug-namespace
//
// Console API: _wos.debug.worldVehicles
//   state()          — layer state snapshot
//   enable()         — switch to world-space rendering
//   disable()        — fall back to DOM markers
//   clear()          — remove all vehicle meshes
//   scale(n)         — multiply all vehicle scales by n (debug)
//   debug(bool)      — toggle internal debug logging
//   testHero()       — place one sedan at camera center
//   testTraffic()    — place sedan + taxi + white truck + graffiti truck
//
// Placement: wall/systems/presentation/worldSpaceVehicleDebug.js
// Load: AFTER worldSpaceVehicleLayer.js
// ──────────────────────────────────────────────────────────────────────────────
(function (global) {
  'use strict';

  function _wsl()  { return global.SBE && global.SBE.WorldSpaceVehicleLayer; }
  function _mvr()  { return global.SBE && global.SBE.MapboxViewportRuntime; }

  // ── Position helpers ──────────────────────────────────────────────────────────

  function _mapCenter() {
    var mvr = _mvr();
    var map = mvr && typeof mvr.getMap === 'function' ? mvr.getMap() : null;
    if (!map) return null;
    try { var c = map.getCenter(); return { lat: c.lat, lng: c.lng }; } catch (e) { return null; }
  }

  // Offset a lat/lng by ~metres in a cardinal direction (good enough for test placement)
  function _offsetLatLng(lat, lng, northM, eastM) {
    var mPerDegLat = 111320;
    var mPerDegLng = 111320 * Math.cos(lat * Math.PI / 180);
    return {
      lat: lat + northM / mPerDegLat,
      lng: lng + eastM  / mPerDegLng,
    };
  }

  // ── Debug object ──────────────────────────────────────────────────────────────

  var _debugObj = {

    state: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return null; }
      var s = wsl.getState();
      console.group('[worldVehicles] state()');
      console.log('active         :', s.active);
      console.log('enabled        :', s.enabled);
      console.log('threeAvailable :', s.threeAvailable);
      console.log('layerAdded     :', s.layerAdded);
      console.log('vehicleCount   :', s.vehicleCount);
      console.log('instanceId     :', s.instanceId);
      console.log('renderReady    :', s.renderReady);
      console.log('transformMode  :', s.transformMode, '| valid:', s.transformValid, '| renders:', s.renderCount);
      if (s.lastTransformError) console.warn('transformError :', s.lastTransformError);
      console.log('beaconActive   :', s.beaconActive);
      console.log('shapeMode      :', s.shapeMode);
      console.log('shapeScale     :', s.shapeScale);
      console.log('adaptiveLOD    :', s.adaptiveLOD);
      console.log('depthEnabled   :', s.depthEnabled, '| depth×' + s.depthMultiplier);
      if (s.lodCounts) {
        console.log('lodCounts      :', 'near:' + s.lodCounts.near, 'mid:' + s.lodCounts.mid,
          'far:' + s.lodCounts.far, 'tiny:' + s.lodCounts.tiny);
      }
      console.log('heroRuntime    :', s.heroRuntimeActive);
      console.log('trafficRuntime :', s.trafficRuntimeActive);
      console.log('regHealthy     :', s.registrationHealthy);
      if (s.heroRuntimeActive && !s.registrationHealthy) {
        console.warn('⚠ runtime active but registry unhealthy — run _wos.debug.worldVehicles.rebind()');
      }
      console.log('fallbackMode   :', s.fallbackMode);
      if (s.lastShapeBuild) {
        var d = s.lastShapeBuild.dimensionsMeters || {};
        console.log('lastShapeBuild :', s.lastShapeBuild.mode,
          '| ' + (d.w != null ? d.w + 'w×' + d.l + 'l×' + d.h + 'h m' : ''),
          '| ' + (s.lastShapeBuild.actorType || '') + '/' + (s.lastShapeBuild.variant || ''));
      }
      if (s.lastShapeBuildError) {
        console.warn('shapeBuildError:', s.lastShapeBuildError.mode, '—', s.lastShapeBuildError.message);
      }
      if (s.lastUpsertFailure) {
        console.warn('lastFailure    :', s.lastUpsertFailure.reason,
          s.lastUpsertFailure.payload ? '| id:' + s.lastUpsertFailure.payload.id + ' lat:' + s.lastUpsertFailure.payload.lat + ' lng:' + s.lastUpsertFailure.payload.lng : '');
      }
      if (s.lastUpsertSuccess) {
        console.log('lastSuccess    : id:' + s.lastUpsertSuccess.id + ' src:' + s.lastUpsertSuccess.source);
      }
      // Stall detection: hero success recorded but transforms not advancing
      if (s.lastTransformAt) {
        var sinceTransform = Date.now() - s.lastTransformAt;
        console.log('lastTransform  :', sinceTransform + 'ms ago',
          s.lastTransformPayload ? '| ' + s.lastTransformPayload.id + ' @ ' + s.lastTransformPayload.shapeMode : '');
        var hrt = global.SBE && global.SBE.HeroVehicleRuntime;
        var heroActive = hrt && typeof hrt.getEntity === 'function' && hrt.getEntity().active;
        if (s.lastUpsertSuccess && s.lastUpsertSuccess.id === 'hero' &&
            heroActive && sinceTransform > 1000) {
          console.warn('⚠ [worldVehicles] hero transform STALLED — ' + sinceTransform +
            'ms since last _applyTransform while HeroVehicleRuntime is active.');
          console.warn('  Live motion authority is not reaching the mesh. Check HeroVehicleRenderer.update() RAF flow.');
        }
      }
      console.log('scale          :', s.scale);
      if (s.vehicles.length) {
        console.group('vehicles');
        s.vehicles.forEach(function (v) {
          console.log(v.id, '|', v.actorType + '/' + v.variant,
            '| src:', v.source,
            '| lat:', v.lat, 'lng:', v.lng,
            '| hdg:', v.headingDeg + '°',
            '| vis:', v.visible);
        });
        console.groupEnd();
      }
      console.groupEnd();
      return s;
    },

    enable: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (!wsl.isActive()) {
        var ok = wsl.start();
        if (!ok) { console.warn('[worldVehicles] could not start — check Three.js and map state'); return; }
      }
      wsl.setEnabled(true);
      console.log('[worldVehicles] enabled — DOM markers will be hidden when actors update');
    },

    disable: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      wsl.setEnabled(false);
      console.log('[worldVehicles] disabled — DOM marker fallback active');
    },

    clear: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      wsl.clear();
      console.log('[worldVehicles] cleared');
    },

    scale: function (n) {
      var wsl = _wsl();
      if (!wsl || typeof wsl.setDebugScale !== 'function') { console.warn('[worldVehicles] setDebugScale unavailable'); return; }
      wsl.setDebugScale(n);
      console.log('[worldVehicles] debugScale →', n);
    },

    debug: function (on) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      wsl.setDebugMode(!!on);
      console.log('[worldVehicles] debugMode →', !!on);
    },

    // trace: enable/disable upsert tracing on both layer and renderer.
    // trace()       → print current trace state
    // trace(true)   → enable (logs each upsert, max 1/s)
    // trace(false)  → disable
    trace: function (on) {
      var wsl = _wsl();
      var hvr = global.SBE && global.SBE.HeroVehicleRenderer;

      if (on === undefined) {
        // Print current trace state
        var wts = wsl && typeof wsl.getUpsertTraceState === 'function'
          ? wsl.getUpsertTraceState() : null;
        var hts = hvr && typeof hvr.getWorldPayloadTraceState === 'function'
          ? hvr.getWorldPayloadTraceState() : null;

        console.group('[worldVehicles] trace()');
        if (wts) {
          console.log('WSL instanceId    :', wts.instanceId);
          console.log('WSL trace enabled :', wts.enabled);
          console.log('WSL renderReady   :', wts.renderReady);
          console.log('WSL vehicleCount  :', wts.vehicleCount);
          console.log('WSL lastFailure   :', wts.lastFailure
            ? wts.lastFailure.reason + ' | ' + JSON.stringify(wts.lastFailure.payload)
            : '—');
          console.log('WSL lastSuccess   :', wts.lastSuccess
            ? 'id:' + wts.lastSuccess.id + ' src:' + wts.lastSuccess.source
            : '—');
        } else {
          console.warn('WorldSpaceVehicleLayer not available');
        }
        if (hts) {
          console.log('HVR trace enabled :', hts.enabled);
          if (hts.lastPayload) {
            console.log('HVR wslInstanceId :', hts.lastPayload.wslInstanceId);
            console.log('HVR payload id    :', hts.lastPayload.payload && hts.lastPayload.payload.id);
            console.log('HVR payload lat   :', hts.lastPayload.payload && hts.lastPayload.payload.lat);
            console.log('HVR payload lng   :', hts.lastPayload.payload && hts.lastPayload.payload.lng);
          } else {
            console.log('HVR lastPayload   : —');
          }
        } else {
          console.warn('HeroVehicleRenderer not available');
        }
        console.groupEnd();
        return { wsl: wts, hvr: hts };
      }

      // Enable or disable both
      if (wsl && typeof wsl.setUpsertTraceEnabled === 'function') wsl.setUpsertTraceEnabled(on);
      if (hvr && typeof hvr.setWorldPayloadTraceEnabled === 'function') hvr.setWorldPayloadTraceEnabled(on);
      console.log('[worldVehicles] trace', on ? 'ENABLED' : 'DISABLED',
        '— logs throttled to 1/s; call trace() with no args to inspect state');
    },

    // visibilityMode: calibrate vehicle mesh scale/presence.
    //   'block'   → replace all vehicle meshes with 20m×10m×8m red box (MeshBasicMaterial)
    //               DOM hero marker stays visible for comparison
    //   'vehicle' → restore procedural vehicle meshes, hide DOM when world-space ready
    visibilityMode: function (m) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (m === undefined) {
        console.log('[worldVehicles] visibilityMode:', wsl.getVisibilityMode ? wsl.getVisibilityMode() : '—');
        return wsl.getVisibilityMode ? wsl.getVisibilityMode() : null;
      }
      if (typeof wsl.setVisibilityMode !== 'function') {
        console.warn('[worldVehicles] setVisibilityMode not available'); return;
      }
      wsl.setVisibilityMode(m);
      if (m === 'block') {
        console.log('[worldVehicles] block mode: 20m×10m×8m red box at hero position');
        console.log('  DOM hero marker stays visible — compare block position to DOM car');
        console.log('  When block confirms position, call visibilityMode(\'vehicle\') to restore');
      } else {
        console.log('[worldVehicles] vehicle mode: procedural mesh, DOM hides when world-space ready');
      }
    },

    // shapeMode: 0531M canonical calibration API. block|slab|wedge|vehicle.
    //   block   → 20×10×8m red tower (position proof)
    //   slab    → 4×8×1.2m flat red footprint (scale/road-seating proof)
    //   wedge   → directional primitive with nose cue (heading proof)
    //   vehicle → first usable 2.5D car (chassis/cabin/windshield/wheels/shadow)
    // DOM marker stays visible in block/slab/wedge; hides only in vehicle mode.
    shapeMode: function (m) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (m === undefined) {
        var cur = wsl.getShapeMode ? wsl.getShapeMode() : '—';
        console.log('[worldVehicles] shapeMode:', cur);
        return cur;
      }
      if (typeof wsl.setShapeMode !== 'function') {
        console.warn('[worldVehicles] setShapeMode not available'); return;
      }
      wsl.setShapeMode(m);
      var notes = {
        block:   '20×10×8m red tower — position proof. DOM marker stays visible.',
        slab:    '4×8×1.2m flat red footprint — scale + road-seating proof. DOM stays visible.',
        wedge:   'directional primitive w/ nose cue — heading proof. DOM stays visible.',
        vehicle: '2.5D car (chassis/cabin/windshield/wheels/shadow). DOM hides when render confirmed.',
      };
      console.log('[worldVehicles] shapeMode →', m, '—', notes[m] || '');
    },

    // rebind: re-register missing vehicles from live runtimes (session recovery)
    rebind: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.attemptSessionRebind !== 'function') {
        console.warn('[worldVehicles] attemptSessionRebind unavailable'); return null;
      }
      var r = wsl.attemptSessionRebind();
      console.group('[worldVehicles] rebind()');
      console.log('heroRecovered    :', r.heroRecovered);
      console.log('trafficRecovered :', r.trafficRecovered);
      console.log('vehiclesBefore   :', r.vehiclesBefore);
      console.log('vehiclesAfter    :', r.vehiclesAfter);
      console.groupEnd();
      return r;
    },

    // lod: adaptive LOD/scale authority toggle.
    //   no arg → print LOD state; true → enable; false → manual shapeScale
    lod: function (on) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (on === undefined) {
        var s = typeof wsl.getScaleState === 'function' ? wsl.getScaleState() : null;
        if (!s) { console.warn('[worldVehicles] scaleState unavailable'); return; }
        console.group('[worldVehicles] lod()');
        console.log('adaptiveLOD   :', s.adaptiveLOD);
        console.log('shapeScale    :', s.shapeScale);
        console.log('zoom          :', s.zoom);
        console.log('pitch         :', s.pitch);
        console.log('cameraProfile :', s.cameraProfile || '—');
        console.groupEnd();
        return s.adaptiveLOD;
      }
      if (typeof wsl.setAdaptiveLOD !== 'function') {
        console.warn('[worldVehicles] setAdaptiveLOD not available'); return;
      }
      var applied = wsl.setAdaptiveLOD(on);
      console.log('[worldVehicles] adaptiveLOD →', applied,
        applied ? '(zoom/type/profile scale active)' : '(manual shapeScale only)');
    },

    // depth: toggle depth-enhanced vehicle meshes.
    //   no arg → print depth status; true → enhanced; false → flatter legacy
    depth: function (on) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (on === undefined) {
        var s = typeof wsl.getDepthState === 'function' ? wsl.getDepthState() : null;
        if (!s) { console.warn('[worldVehicles] depthState unavailable'); return; }
        console.group('[worldVehicles] depth()');
        console.log('depthEnabled    :', s.depthEnabled);
        console.log('cameraProfile   :', s.cameraProfile || '—');
        console.log('depthMultiplier :', s.depthMultiplier);
        console.groupEnd();
        return s.depthEnabled;
      }
      if (typeof wsl.setDepthEnabled !== 'function') {
        console.warn('[worldVehicles] setDepthEnabled not available'); return;
      }
      var applied = wsl.setDepthEnabled(on);
      console.log('[worldVehicles] depthEnabled →', applied,
        applied ? '(raised 2.5D meshes)' : '(flatter legacy meshes)');
    },

    // depthState: per-vehicle depth + dimension report
    depthState: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getDepthState !== 'function') {
        console.warn('[worldVehicles] depthState unavailable'); return null;
      }
      var s = wsl.getDepthState();
      console.group('[worldVehicles] depthState() — depth:' + s.depthEnabled +
        ' profile:' + (s.cameraProfile || '—') + ' ×' + s.depthMultiplier);
      s.vehicles.forEach(function (v) {
        var dm = v.dimensions || {};
        console.log(v.id, '|', (v.actorType || '?') + '/' + (v.variant || '?'),
          '| lod:', v.lodTier,
          '| profile:', v.meshProfile,
          '| depth×' + v.depthMultiplier,
          '| final×' + v.finalScale,
          '| dims:', JSON.stringify(dm));
      });
      if (!s.vehicles.length) console.warn('[worldVehicles] no vehicles to report');
      console.groupEnd();
      return s;
    },

    // ── 3D primitive proof (0601G) ──────────────────────────────────────────────

    // primitive3d: toggle deliberately chunky 3D proof meshes (car + truck).
    //   true → primitive proof; false → normal vehicle mode; no arg → status.
    primitive3d: function (on) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return { ok: false, reason: 'world_layer_not_ready' }; }
      if (on === undefined) {
        var cur = typeof wsl.getPrimitive3d === 'function' ? wsl.getPrimitive3d() : null;
        console.log('[worldVehicles] primitive3d:', cur,
          '| forceNear:', typeof wsl.getPrimitive3dForceNear === 'function' ? wsl.getPrimitive3dForceNear() : '—');
        return cur;
      }
      if (typeof wsl.setPrimitive3d !== 'function') {
        console.warn('[worldVehicles] setPrimitive3d unavailable'); return { ok: false, reason: 'world_layer_not_ready' };
      }
      var applied = wsl.setPrimitive3d(on);
      console.log('[worldVehicles] primitive3d →', applied,
        applied ? '(chunky 3D proof meshes; shapeMode unaffected)' : '(normal vehicle mode)');
      return applied;
    },

    primitive3dForceNear: function (on) {
      var wsl = _wsl();
      if (!wsl || typeof wsl.setPrimitive3dForceNear !== 'function') {
        console.warn('[worldVehicles] primitive3dForceNear unavailable'); return;
      }
      if (on === undefined) {
        var cur = wsl.getPrimitive3dForceNear();
        console.log('[worldVehicles] primitive3dForceNear:', cur);
        return cur;
      }
      var applied = wsl.setPrimitive3dForceNear(on);
      console.log('[worldVehicles] primitive3dForceNear →', applied);
      return applied;
    },

    // testPrimitive3D: place a primitive car + truck at/near map center (no Drive)
    testPrimitive3D: function () {
      var wsl = _wsl();
      if (!global.THREE) { console.warn('[worldVehicles] three_not_available'); return { ok: false, reason: 'three_not_available' }; }
      if (!wsl) { console.warn('[worldVehicles] world_layer_not_ready'); return { ok: false, reason: 'world_layer_not_ready' }; }
      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);
      if (!wsl.isRenderReady()) { console.warn('[worldVehicles] world_layer_not_ready'); return { ok: false, reason: 'world_layer_not_ready' }; }
      if (typeof wsl.setPrimitive3d === 'function') wsl.setPrimitive3d(true);

      var c = _mapCenter();
      if (!c) { console.warn('[worldVehicles] map center unavailable'); return { ok: false, reason: 'map_unavailable' }; }

      var carId = 'primitive3d_car_test', truckId = 'primitive3d_truck_test';
      var carOK = wsl.upsertVehicle({
        id: carId, actorType: 'hero_car', variant: 'sedan_red',
        lat: c.lat, lng: c.lng, headingDeg: 0, scale: 1, visible: true, source: 'test',
      });
      var tp = _offsetLatLng(c.lat, c.lng, 0, 25);   // 25m east
      var truckOK = wsl.upsertVehicle({
        id: truckId, actorType: 'box_truck', variant: 'clean_white',
        lat: tp.lat, lng: tp.lng, headingDeg: 0, scale: 1, visible: true, source: 'test',
      });
      var result = { added: !!(carOK && truckOK), carId: carId, truckId: truckId, primitive3d: true };
      console.log('[worldVehicles] testPrimitive3D —', JSON.stringify(result));
      return result;
    },

    clearPrimitive3D: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (typeof wsl.removeVehicle === 'function') {
        wsl.removeVehicle('primitive3d_car_test');
        wsl.removeVehicle('primitive3d_truck_test');
      }
      console.log('[worldVehicles] clearPrimitive3D — test primitives removed');
    },

    primitiveState: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getPrimitiveState !== 'function') {
        console.warn('[worldVehicles] primitiveState unavailable'); return null;
      }
      var s = wsl.getPrimitiveState();
      console.group('[worldVehicles] primitiveState()');
      console.log('primitive3dEnabled :', s.primitive3dEnabled, '| forceNear:', s.forceNear);
      console.log('vehicleCount       :', s.vehicleCount);
      console.log('primitiveCount     :', s.primitiveCount,
        '(car:' + s.carPrimitiveCount + ' truck:' + s.truckPrimitiveCount + ')');
      if (s.lastPrimitiveBuild) console.log('lastBuild          :', s.lastPrimitiveBuild.kind, '@', new Date(s.lastPrimitiveBuild.timestamp).toLocaleTimeString());
      if (s.lastPrimitiveError) console.warn('lastError          :', s.lastPrimitiveError.message);
      console.groupEnd();
      return s;
    },

    // ── Transform migration (0601J) ─────────────────────────────────────────────

    // transformMode: switch WSL world transform path.
    //   'modelMatrix' (default) — canonical Mapbox path; 'vehicleMatrix' — legacy.
    transformMode: function (m) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (m === undefined) {
        var cur = typeof wsl.getTransformMode === 'function' ? wsl.getTransformMode() : null;
        console.log('[worldVehicles] transformMode:', cur);
        return cur;
      }
      if (typeof wsl.setTransformMode !== 'function') {
        console.warn('[worldVehicles] setTransformMode unavailable'); return;
      }
      var applied = wsl.setTransformMode(m);
      console.log('[worldVehicles] transformMode →', applied,
        applied === 'modelMatrix' ? '(canonical Mapbox model-matrix path)' : '(legacy mesh-position path)');
      return applied;
    },

    transformState: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getTransformState !== 'function') {
        console.warn('[worldVehicles] transformState unavailable'); return null;
      }
      var s = wsl.getTransformState();
      console.group('[worldVehicles] transformState() — mode:' + s.mode);
      console.log('vehicleCount       :', s.vehicleCount);
      console.log('modelMatrixCount   :', s.modelMatrixCount, '| vehicleMatrixCount:', s.vehicleMatrixCount);
      console.log('renderCount        :', s.renderCount, '| lastRenderAt:', s.lastRenderAt ? new Date(s.lastRenderAt).toLocaleTimeString() : '—');
      if (s.lastTransformError) console.warn('lastTransformError :', s.lastTransformError);
      console.groupEnd();
      return s;
    },

    // transformCompare: add one modelMatrix cube + one vehicleMatrix cube nearby,
    // report which path renders. Recommendation drives the production default.
    transformCompare: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return { recommendation: 'neither_valid' }; }
      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);
      var c = _mapCenter();
      if (!c) { console.warn('[worldVehicles] map center unavailable'); return { recommendation: 'neither_valid' }; }

      // Clean prior comparison objects
      wsl.removeVehicle('transformcmp_model');
      wsl.removeVehicle('transformcmp_vehicle');

      var startMode = wsl.getTransformMode();

      // modelMatrix cube — a primitive car via the model path
      wsl.setTransformMode('modelMatrix');
      var mOK = wsl.upsertVehicle({
        id: 'transformcmp_model', actorType: 'hero_car', variant: 'sedan_red',
        lat: c.lat, lng: c.lng, headingDeg: 0, scale: 1, visible: true, source: 'test',
      });

      // vehicleMatrix cube — offset 40m east, legacy path
      var ep = _offsetLatLng(c.lat, c.lng, 0, 40);
      wsl.setTransformMode('vehicleMatrix');
      var vOK = wsl.upsertVehicle({
        id: 'transformcmp_vehicle', actorType: 'hero_car', variant: 'sedan_dark',
        lat: ep.lat, lng: ep.lng, headingDeg: 0, scale: 1, visible: true, source: 'test',
      });

      // Restore production default (modelMatrix)
      wsl.setTransformMode(startMode === 'vehicleMatrix' ? 'vehicleMatrix' : 'modelMatrix');

      // 0601K — separate transformed / rendered / projected / confidence.
      // Render happens on the next Mapbox RAF frame, so we evaluate truth twice:
      // an immediate snapshot, then an authoritative deferred read after frames.
      function _truth(id) {
        var st = wsl.getState();
        var row = null;
        st.vehicles.forEach(function (x) { if (x.id === id) row = x; });
        return row || { transformed: false, rendered: false, projectedOnScreen: false, visibilityConfidence: 'none' };
      }
      function _recommend(mt, vt) {
        var mRP = mt.rendered || mt.projectedOnScreen;
        var vRP = vt.rendered || vt.projectedOnScreen;
        if (mRP && vRP) return 'both_valid';
        if (mRP && !vRP) return 'use_modelMatrix';
        if (vRP && !mRP) return 'use_vehicleMatrix';
        if (mt.transformed || vt.transformed) return 'render_unproven';
        return 'neither_valid';
      }
      function _build(label, deferred) {
        var mt = _truth('transformcmp_model'), vt = _truth('transformcmp_vehicle');
        var rec = _recommend(mt, vt);
        var out = {
          modelMatrixAdded: !!mOK, vehicleMatrixAdded: !!vOK,
          modelMatrixTransformed: mt.transformed, vehicleMatrixTransformed: vt.transformed,
          modelMatrixRendered: mt.rendered, vehicleMatrixRendered: vt.rendered,
          modelMatrixProjectedOnScreen: mt.projectedOnScreen, vehicleMatrixProjectedOnScreen: vt.projectedOnScreen,
          modelMatrixVisibilityConfidence: mt.visibilityConfidence, vehicleMatrixVisibilityConfidence: vt.visibilityConfidence,
          // Deprecated aliases map to RENDER truth, never lastTransformAt
          modelMatrixVisibleDeprecated: mt.rendered, vehicleMatrixVisibleDeprecated: vt.rendered,
          recommendation: rec,
        };
        console.group('[worldVehicles] transformCompare() ' + label + ' → ' + rec);
        console.log('⚠ transformed does not mean visible.');
        console.log('model  : transformed=' + mt.transformed, 'rendered=' + mt.rendered,
          'projected=' + mt.projectedOnScreen, 'confidence=' + mt.visibilityConfidence);
        console.log('vehicle: transformed=' + vt.transformed, 'rendered=' + vt.rendered,
          'projected=' + vt.projectedOnScreen, 'confidence=' + vt.visibilityConfidence);
        if (rec === 'render_unproven') console.warn('  transform succeeded but render NOT proven — wait a frame / check viewport');
        if (rec === 'neither_valid') console.warn('  ✗ neither transformed — return to 0601I threeProof harness');
        console.groupEnd();
        return out;
      }

      // Authoritative read after a few frames have rendered.
      global.setTimeout(function () { _build('(settled)', true); }, 300);
      return _build('(immediate)', false);
    },

    // renderTruth: per-object transformed/rendered/projected/confidence (no false "visible")
    renderTruth: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getRenderTruth !== 'function') {
        console.warn('[worldVehicles] renderTruth unavailable'); return null;
      }
      var s = wsl.getRenderTruth();
      console.group('[worldVehicles] renderTruth() — ' +
        s.transformedCount + ' transformed, ' + s.renderedCount + ' rendered, ' +
        s.projectedOnScreenCount + ' projected, ' + s.visualConfirmedCount + ' confirmed');
      console.log('renderCount:', s.renderCount, '| lastRendered:', s.lastRenderedVehicleId || '—',
        '| objs/frame:', s.lastRenderObjectCount, '| skipped:', s.lastRenderSkippedCount);
      s.vehicles.forEach(function (v) {
        var sp = v.screenPosition;
        console.log(v.id,
          '| transformed:', v.transformed ? 'yes' : 'no',
          '| rendered:', v.rendered ? 'yes' : 'no',
          '| projected:', v.projectedOnScreen ? 'yes' : 'no',
          '| confidence:', v.visibilityConfidence,
          sp ? '| screen:(' + sp.x + ',' + sp.y + ') ' + (sp.inViewport ? 'in' : sp.nearViewport ? 'near' : 'off+' + sp.distanceFromViewportPx + 'px') : '');
      });
      if (s.visualConfirmedCount === 0) console.log('(no object is visual_confirmed — "visible" is never claimed automatically)');
      console.groupEnd();
      return s;
    },

    // visibilityTruth: alias of renderTruth for discoverability
    visibilityTruth: function () { return this.renderTruth(); },

    confirmVisible: function (id) {
      var wsl = _wsl();
      if (!wsl || typeof wsl.confirmVisible !== 'function') { console.warn('[worldVehicles] confirmVisible unavailable'); return false; }
      var ok = wsl.confirmVisible(id);
      console.log('[worldVehicles] confirmVisible(' + id + ') →', ok ? 'marked visual_confirmed' : 'id not found');
      return ok;
    },
    clearVisibilityConfirm: function (id) {
      var wsl = _wsl();
      if (!wsl || typeof wsl.clearVisibilityConfirm !== 'function') { console.warn('[worldVehicles] clearVisibilityConfirm unavailable'); return false; }
      var ok = wsl.clearVisibilityConfirm(id);
      console.log('[worldVehicles] clearVisibilityConfirm(' + id + ') →', ok ? 'cleared' : 'id not found');
      return ok;
    },

    // visuals: per-vehicle visual identity (registry-derived)
    visuals: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getVisualIdentityState !== 'function') {
        console.warn('[worldVehicles] visuals unavailable'); return null;
      }
      var s = wsl.getVisualIdentityState();
      console.group('[worldVehicles] visuals() — registry:' + (s.registryLoaded ? 'loaded' : 'MISSING'));
      s.vehicles.forEach(function (v) {
        console.log(v.id, '|', (v.actorType || '?') + '/' + (v.variant || '?'),
          '| lod:', v.lodTier,
          '| profile:', v.visualProfile,
          '| body:', v.bodyColor,
          (v.graffiti ? '| graffiti' : ''), (v.sign ? '| taxi-sign' : ''),
          '| vis:', v.worldVisible);
      });
      if (!s.vehicles.length) console.warn('[worldVehicles] no vehicles to report');
      console.groupEnd();
      return s;
    },

    // scaleState: per-vehicle scale breakdown + LOD tiers
    scaleState: function () {
      var wsl = _wsl();
      if (!wsl || typeof wsl.getScaleState !== 'function') {
        console.warn('[worldVehicles] scaleState unavailable'); return null;
      }
      var s = wsl.getScaleState();
      console.group('[worldVehicles] scaleState() — adaptiveLOD:' + s.adaptiveLOD +
        ' zoom:' + s.zoom + ' profile:' + (s.cameraProfile || '—'));
      s.vehicles.forEach(function (v) {
        console.log(v.id, '|', (v.actorType || '?') + '/' + (v.variant || '?'),
          '| lod:', v.lodTier,
          '| zoom×' + v.zoomScale, 'type×' + v.typeScale, 'profile×' + v.profileScale,
          '→ final×' + v.finalScale);
      });
      if (!s.vehicles.length) console.warn('[worldVehicles] no vehicles to report');
      console.groupEnd();
      return s;
    },

    // shapeScale: debug multiplier on final mesh group scale. Default 1.
    shapeScale: function (s) {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      if (s === undefined) {
        var cur = wsl.getShapeScale ? wsl.getShapeScale() : 1;
        console.log('[worldVehicles] shapeScale:', cur);
        return cur;
      }
      if (typeof wsl.setShapeScale !== 'function') {
        console.warn('[worldVehicles] setShapeScale not available'); return;
      }
      var applied = wsl.setShapeScale(s);
      console.log('[worldVehicles] shapeScale →', applied);
    },

    // beacon: places a 20×20×100m bright red box at the live hero position.
    // Tracks hero via RAF. Does NOT hide the DOM hero marker.
    // If beacon appears → custom layer renders correctly.
    // If beacon is invisible → matrix/Mercator transform/render path is wrong.
    beacon: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }

      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);

      if (!wsl.isRenderReady()) {
        console.warn('[worldVehicles] beacon: renderReady=false — wait for layer to initialise then retry');
        _debugObj.state();
        return false;
      }

      var ok = wsl.startBeacon();
      if (ok) {
        console.log('[worldVehicles] beacon ACTIVE — look for a tall red box above the hero car');
        console.log('  beacon visible → layer rendering works; check vehicle mesh scale/transform');
        console.log('  beacon invisible → Mercator/matrix path not working; check render() callback');
      }
      _debugObj.state();
      return ok;
    },

    clearBeacon: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }
      wsl.stopBeacon();
    },

    // testHero: STATIC TEST — places one sedan at map center, NOT bound to live route
    testHero: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }

      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);

      var pos = _mapCenter();
      if (!pos) { console.warn('[worldVehicles] testHero: map center unavailable'); return; }

      var ok = wsl.upsertVehicle({
        id:        'test_hero',
        actorType: 'hero_car',
        variant:   'sedan_red',
        lat:       pos.lat,
        lng:       pos.lng,
        headingDeg: 0,
        scale:     1,
        visible:   true,
        source:    'test',
      });
      console.log('[worldVehicles] STATIC testHero placed at',
        pos.lat.toFixed(5), pos.lng.toFixed(5),
        '— NOT bound to live route. Use liveHero() for runtime binding.');
      return ok;
    },

    // liveHero: enable world-space rendering and confirm the live hero is active.
    //
    // Does NOT own frame updates — HeroVehicleRenderer.update() is called every
    // RAF by HeroVehicleRuntime and will continuously upsert 'hero' once enabled.
    //
    // Steps:
    //   1. Enable + start WorldSpaceVehicleLayer
    //   2. Remove stale test_hero mesh (avoids two sedan_red meshes)
    //   3. Confirm HeroVehicleRuntime is active and has a valid entity
    //   4. Print state — ongoing updates happen automatically via renderer RAF
    liveHero: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return null; }

      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);

      // Remove stale static test mesh so it doesn't sit frozen beside the live car
      if (typeof wsl.removeVehicle === 'function') wsl.removeVehicle('test_hero');

      // Confirm live hero is running
      var hrt = global.SBE && global.SBE.HeroVehicleRuntime;
      if (!hrt || typeof hrt.getEntity !== 'function') {
        console.warn('[worldVehicles] liveHero: HeroVehicleRuntime.getEntity() not available');
        return null;
      }
      var entity = hrt.getEntity();
      if (!entity.active) {
        console.warn('[worldVehicles] liveHero: hero not active — launch Drive first, then call liveHero()');
        return null;
      }

      var ready = typeof wsl.isRenderReady === 'function' && wsl.isRenderReady();
      console.log('[worldVehicles] liveHero confirmed —',
        'renderReady:', ready,
        '| lat:', entity.lat.toFixed(5),
        '| hdg:', entity.headingDeg.toFixed(1) + '°',
        '| prog:', entity.progressPct + '%');
      console.log('  HeroVehicleRenderer.update() will push source:hero-live every RAF.');
      if (!ready) {
        console.warn('[worldVehicles] isRenderReady=false — Three.js onAdd may still be pending.');
        console.warn('  DOM hero stays visible. Call state() in ~1s to recheck.');
      } else {
        console.log('  DOM hero will hide on the next frame where upsert succeeds.');
      }

      return _debugObj.state();
    },

    // testTraffic: sedan + taxi + white truck + graffiti truck at fixed offsets
    testTraffic: function () {
      var wsl = _wsl();
      if (!wsl) { console.warn('[worldVehicles] layer not loaded'); return; }

      if (!wsl.isActive()) wsl.start();
      if (!wsl.getEnabled()) wsl.setEnabled(true);

      var c = _mapCenter();
      if (!c) { console.warn('[worldVehicles] testTraffic: map center unavailable'); return; }

      var specs = [
        { id: 'test_sedan',   actorType: 'traffic_car', variant: 'sedan_dark',            north:  30, east:   0, hdg:  0 },
        { id: 'test_taxi',    actorType: 'traffic_car', variant: 'taxi_yellow',            north:   0, east:  20, hdg: 90 },
        { id: 'test_truck_w', actorType: 'box_truck',   variant: 'clean_white',            north: -30, east:   0, hdg: 180 },
        { id: 'test_truck_g', actorType: 'box_truck',   variant: 'sticker_graffiti_test',  north:   0, east: -20, hdg: 270 },
      ];

      specs.forEach(function (s) {
        var p = _offsetLatLng(c.lat, c.lng, s.north, s.east);
        var ok = wsl.upsertVehicle({
          id: s.id, actorType: s.actorType, variant: s.variant,
          lat: p.lat, lng: p.lng, headingDeg: s.hdg,
          scale: 1, visible: true, source: 'test',
        });
        console.log('[worldVehicles] testTraffic placed', s.id, s.variant, 'ok:', ok);
      });
    },

  };

  // ── Bind ──────────────────────────────────────────────────────────────────────

  function _bind() {
    global._wos             = global._wos             || {};
    global._wos.debug       = global._wos.debug       || {};
    global._wos.debug.worldVehicles = _debugObj;
  }
  _bind();
  global.setTimeout(_bind, 300);
  global.setTimeout(_bind, 1000);
  global.setTimeout(_bind, 2500);

  console.log('[WorldSpaceVehicleDebug] loaded — _wos.debug.worldVehicles');

})(window);
