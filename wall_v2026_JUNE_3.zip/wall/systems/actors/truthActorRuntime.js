// ── TruthActorRuntime v1.0.0 ──────────────────────────────────────────────────
// 0603A_WOS_TruthInfrastructureActorAuthority_v1.0.0
// Status: active | Classification: actor-authority (logic layer)
//
// Accepts NORMALIZED actor updates (from future feeds / debug), resolves identity
// + visual profile, maintains live actor state, upserts renderable actors into
// the existing WorldSpaceVehicleLayer, and prunes stale actors by TTL.
//
// Authority:
//   OWNS: truth/synthetic actor lifecycle (NOT hero, AIS, aircraft, showcase)
//   USES: ActorIdentityRegistry, ActorVisualRegistry, WorldSpaceVehicleLayer
//   MUST NOT: parse feeds, own meshes, route/interpolate truth, touch hero
// Load AFTER the actor registries and worldSpaceVehicleLayer.js.
// ──────────────────────────────────────────────────────────────────────────────
(function (global) {
  'use strict';
  var SBE = (global.SBE = global.SBE || {});
  var VERSION = '1.0.0';

  var _active  = false;
  var _actors  = {};   // actorId → live actor record
  var _stats   = { lastUpdateAt: 0, lastPruneAt: 0, lastError: null };

  function _now() { return Date.now(); }
  function _wsl() { return SBE.WorldSpaceVehicleLayer; }
  function _idReg() { return SBE.ActorIdentityRegistry; }
  function _visReg() { return SBE.ActorVisualRegistry; }

  // Concrete WSL mesh actorType from a visual shape (presentation only).
  function _wslActorType(profile) {
    var s = profile && (profile.wslShape || profile.shape);
    if (s === 'box_truck') return 'box_truck';
    if (s === 'traffic_car') return 'traffic_car';
    return 'traffic_car';   // prop / unknown → small marker fallback
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────────
  function start() {
    _active = true;
    // Enable the render layer only on start (never mutate hero behavior).
    var wsl = _wsl();
    try {
      if (wsl) {
        if (typeof wsl.isActive === 'function' && !wsl.isActive() && typeof wsl.start === 'function') wsl.start();
        if (typeof wsl.getEnabled === 'function' && !wsl.getEnabled() && typeof wsl.setEnabled === 'function') wsl.setEnabled(true);
      }
    } catch (e) { _stats.lastError = 'wsl_start_failed:' + (e && e.message ? e.message : e); }
    console.log('[TruthActorRuntime] v' + VERSION + ' started');
    return true;
  }

  function stop() { _active = false; console.log('[TruthActorRuntime] stopped'); return true; }

  function clear() {
    var wsl = _wsl();
    Object.keys(_actors).forEach(function (id) {
      try { if (wsl && typeof wsl.removeVehicle === 'function') wsl.removeVehicle(id); } catch (e) {}
    });
    _actors = {};
    console.log('[TruthActorRuntime] cleared');
    return true;
  }

  // ── Render adapter (WorldSpaceVehicleLayer only, public API only) ──────────────
  function _renderActor(record) {
    var wsl = _wsl();
    if (!wsl || typeof wsl.upsertVehicle !== 'function') return false;   // store state, don't throw
    var p = record.visualProfile || {};
    try {
      return !!wsl.upsertVehicle({
        id:         record.actorId,
        lat:        record.lat,
        lng:        record.lng,
        headingDeg: record.headingDeg || 0,
        actorType:  _wslActorType(p),
        variant:    p.variant || 'sedan_dark',
        scale:      p.scale != null ? p.scale : 1.5,
        visible:    true,
        source:     record.sourceId,           // never 'hero-live'
        label:      record.label,
      });
    } catch (e) { _stats.lastError = 'upsert_failed:' + (e && e.message ? e.message : e); return false; }
  }

  // ── upsertActor(normalizedUpdate) ──────────────────────────────────────────────
  function upsertActor(update) {
    if (!update || update.lat == null || update.lng == null) { _stats.lastError = 'invalid_update'; return null; }
    var idReg = _idReg();
    if (!idReg) { _stats.lastError = 'identity_registry_missing'; return null; }

    var ttlMs = update.ttlMs != null ? update.ttlMs : 30000;
    var identity = idReg.resolveIdentity({
      sourceId:       update.sourceId,
      sourceEntityId: update.sourceEntityId,
      actorType:      update.actorType,
      label:          update.label,
      ttlMs:          ttlMs,
      tags:           update.tags,
    });

    var visReg = _visReg();
    var profile = visReg && typeof visReg.getVisualProfile === 'function'
      ? visReg.getVisualProfile({ actorType: update.actorType }) : null;

    var now = _now();
    var record = _actors[identity.actorId] || {
      actorId: identity.actorId, sourceId: update.sourceId, actorType: update.actorType,
      firstSeenAt: now,
    };
    record.sourceEntityId = identity.sourceEntityId;
    record.label          = update.label || identity.label;
    record.lat            = update.lat;
    record.lng            = update.lng;
    record.headingDeg     = update.headingDeg || 0;
    record.speedMps       = update.speedMps != null ? update.speedMps : null;
    record.ttlMs          = ttlMs;
    record.lastSeenAt     = now;
    record.timestampMs    = update.timestampMs || now;
    record.metadata       = update.metadata || {};
    record.visualProfile  = profile;
    _actors[identity.actorId] = record;

    _renderActor(record);
    _stats.lastUpdateAt = now;
    return identity.actorId;
  }

  function removeActor(actorId) {
    if (!_actors[actorId]) return false;
    var wsl = _wsl();
    try { if (wsl && typeof wsl.removeVehicle === 'function') wsl.removeVehicle(actorId); }
    catch (e) { _stats.lastError = 'remove_failed:' + (e && e.message ? e.message : e); }
    delete _actors[actorId];
    var idReg = _idReg();
    if (idReg && typeof idReg.remove === 'function') { try { idReg.remove(actorId); } catch (e2) {} }
    return true;
  }

  function getActor(actorId) { return _actors[actorId] || null; }
  function listActors() { return Object.keys(_actors).map(function (k) { return _actors[k]; }); }

  // ── TTL prune ─────────────────────────────────────────────────────────────────
  function prune(nowMs) {
    nowMs = nowMs || _now();
    var removed = [];
    Object.keys(_actors).forEach(function (id) {
      var a = _actors[id];
      if (a.ttlMs > 0 && (nowMs - a.lastSeenAt) > a.ttlMs) removed.push(id);
    });
    removed.forEach(function (id) { removeActor(id); });
    _stats.lastPruneAt = nowMs;
    return removed;
  }

  // ── State / audit ──────────────────────────────────────────────────────────────
  function getState() {
    var sourceCounts = {}, typeCounts = {};
    Object.keys(_actors).forEach(function (id) {
      var a = _actors[id];
      sourceCounts[a.sourceId] = (sourceCounts[a.sourceId] || 0) + 1;
      typeCounts[a.actorType]  = (typeCounts[a.actorType] || 0) + 1;
    });
    return {
      version:      VERSION,
      active:       _active,
      actorCount:   Object.keys(_actors).length,
      sourceCounts: sourceCounts,
      typeCounts:   typeCounts,
      lastUpdateAt: _stats.lastUpdateAt,
      lastPruneAt:  _stats.lastPruneAt,
      lastError:    _stats.lastError,
    };
  }

  SBE.TruthActorRuntime = Object.freeze({
    VERSION:     VERSION,
    start:       start,
    stop:        stop,
    clear:       clear,
    upsertActor: upsertActor,
    removeActor: removeActor,
    getActor:    getActor,
    getState:    getState,
    listActors:  listActors,
    prune:       prune,
  });

  console.log('[TruthActorRuntime] v' + VERSION + ' loaded');
})(window);
