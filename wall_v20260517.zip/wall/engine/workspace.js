(function initWorkspace(global) {
  "use strict";
  var SBE = (global.SBE = global.SBE || {});

  // ── Workspace Engine (0518_WOS_WorkspaceArchitecture_v1.0.0) ────────────────
  //
  // WOS is no longer a single runtime. It is a multi-document creative
  // environment. Each document has a type, a runtime context, and a persistent
  // identity. Documents live in tabs. The active document governs what the
  // canvas and inspector display.
  //
  // Document types
  //   route       — route / traffic world  (the live simulation)
  //   canvas      — freeform canvas / symbol layout
  //   soundscape  — audio / sample mapping
  //   world       — world parameters, ecology settings, lighting
  //
  // Sidebar contexts (lower-left icon strip)
  //   world       — world ecology sidebar
  //   layers      — layer visibility
  //   sequences   — sequence / automation lanes
  //   assets      — asset library
  //   settings    — workspace settings
  //   help        — help & docs

  // ── Document type metadata ─────────────────────────────────────────────────
  var DOC_TYPES = {
    route:      { label: "Route",      accent: "#4a9eff", icon: "⬡" },
    canvas:     { label: "Canvas",     accent: "#a78bfa", icon: "◻" },
    soundscape: { label: "Soundscape", accent: "#34d399", icon: "♪" },
    world:      { label: "World",      accent: "#fb923c", icon: "◎" },
  };

  var SIDEBAR_CONTEXTS = ["world", "layers", "sequences", "assets", "settings", "help"];

  // ── Internal state ─────────────────────────────────────────────────────────
  var _docs        = [];        // ordered array of document objects
  var _activeId    = null;      // id of currently active document
  var _sidebarCtx  = "world";   // active sidebar context key
  var _nextId      = 1;
  var _listeners   = {};        // event → [fn]

  // ── Document factory ───────────────────────────────────────────────────────
  function _makeDoc(type, name, opts) {
    var meta = DOC_TYPES[type];
    if (!meta) throw new Error("[Workspace] unknown document type: " + type);
    var doc = {
      id:        "doc-" + (_nextId++),
      type:      type,
      name:      name || (meta.label + " " + _nextId),
      accent:    meta.accent,
      icon:      meta.icon,
      modified:  false,
      createdAt: Date.now(),
      runtime:   null,          // set by RuntimeManager when attached
      meta:      opts || {},
    };
    return doc;
  }

  // ── Event emitter ──────────────────────────────────────────────────────────
  function _emit(event, payload) {
    var fns = _listeners[event] || [];
    for (var i = 0; i < fns.length; i++) {
      try { fns[i](payload); } catch (e) { /* isolate listener errors */ }
    }
  }

  function on(event, fn) {
    if (!_listeners[event]) _listeners[event] = [];
    _listeners[event].push(fn);
  }

  function off(event, fn) {
    if (!_listeners[event]) return;
    _listeners[event] = _listeners[event].filter(function(f) { return f !== fn; });
  }

  // ── Document lifecycle ─────────────────────────────────────────────────────
  function createDocument(type, name, opts) {
    var doc = _makeDoc(type, name, opts);
    _docs.push(doc);
    _emit("documentCreated", { doc: doc });
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
    return doc;
  }

  function openDocument(id) {
    var doc = _getById(id);
    if (!doc) { console.warn("[Workspace] openDocument: id not found:", id); return; }
    var prev = _activeId;
    _activeId = id;
    _emit("activeDocumentChanged", { doc: doc, prevId: prev });
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
    return doc;
  }

  function closeDocument(id) {
    var idx = _docs.findIndex(function(d) { return d.id === id; });
    if (idx === -1) return;
    var closing = _docs[idx];
    _docs.splice(idx, 1);

    // If closing the active doc, activate adjacent
    if (_activeId === id) {
      if (_docs.length > 0) {
        var nextIdx = Math.min(idx, _docs.length - 1);
        _activeId = _docs[nextIdx].id;
        _emit("activeDocumentChanged", { doc: _docs[nextIdx], prevId: id });
      } else {
        _activeId = null;
        _emit("activeDocumentChanged", { doc: null, prevId: id });
      }
    }

    _emit("documentClosed", { doc: closing });
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
  }

  function duplicateDocument(id) {
    var src = _getById(id);
    if (!src) return;
    var copy = _makeDoc(src.type, src.name + " copy", JSON.parse(JSON.stringify(src.meta)));
    // Insert after source
    var idx = _docs.findIndex(function(d) { return d.id === id; });
    _docs.splice(idx + 1, 0, copy);
    _emit("documentCreated", { doc: copy });
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
    return copy;
  }

  function renameDocument(id, name) {
    var doc = _getById(id);
    if (!doc) return;
    doc.name = name;
    doc.modified = true;
    _emit("documentRenamed", { doc: doc });
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
  }

  function reorderTab(fromId, toId) {
    var fi = _docs.findIndex(function(d) { return d.id === fromId; });
    var ti = _docs.findIndex(function(d) { return d.id === toId; });
    if (fi === -1 || ti === -1 || fi === ti) return;
    var doc = _docs.splice(fi, 1)[0];
    _docs.splice(ti, 0, doc);
    _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId });
  }

  function markModified(id) {
    var doc = _getById(id);
    if (doc) { doc.modified = true; _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId }); }
  }

  function markSaved(id) {
    var doc = _getById(id);
    if (doc) { doc.modified = false; _emit("tabsChanged", { docs: _docs.slice(), activeId: _activeId }); }
  }

  // ── Sidebar ────────────────────────────────────────────────────────────────
  function setSidebarContext(ctx) {
    if (SIDEBAR_CONTEXTS.indexOf(ctx) === -1) {
      console.warn("[Workspace] unknown sidebar context:", ctx);
      return;
    }
    var prev = _sidebarCtx;
    _sidebarCtx = ctx;
    _emit("sidebarContextChanged", { context: ctx, prev: prev });
  }

  function getSidebarContext() { return _sidebarCtx; }

  // ── Accessors ──────────────────────────────────────────────────────────────
  function getActiveDocument() {
    return _activeId ? _getById(_activeId) : null;
  }

  function getAllDocuments() { return _docs.slice(); }

  function getDocumentById(id) { return _getById(id); }

  function getDocTypes() { return DOC_TYPES; }

  function getSidebarContexts() { return SIDEBAR_CONTEXTS.slice(); }

  function _getById(id) {
    for (var i = 0; i < _docs.length; i++) {
      if (_docs[i].id === id) return _docs[i];
    }
    return null;
  }

  // ── RuntimeManager ─────────────────────────────────────────────────────────
  // Lightweight bridge: documents can request a named runtime object be
  // attached. The workspace tracks attachment; actual runtime boot is
  // handled externally (main.js / engine modules).
  var RuntimeManager = (function() {
    var _runtimes = {};

    function register(name, rt) {
      _runtimes[name] = rt;
      _emit("runtimeRegistered", { name: name, runtime: rt });
    }

    function get(name) { return _runtimes[name] || null; }

    function attachToDocument(docId, runtimeName) {
      var doc = _getById(docId);
      if (!doc) return;
      doc.runtime = _runtimes[runtimeName] || null;
      _emit("runtimeAttached", { docId: docId, runtimeName: runtimeName, runtime: doc.runtime });
    }

    function listRuntimes() { return Object.keys(_runtimes); }

    return { register: register, get: get, attachToDocument: attachToDocument, listRuntimes: listRuntimes };
  })();

  // ── Serialization ──────────────────────────────────────────────────────────
  function serialize() {
    return {
      version:    "0518.1",
      activeId:   _activeId,
      sidebarCtx: _sidebarCtx,
      docs:       _docs.map(function(d) {
        return { id: d.id, type: d.type, name: d.name, modified: d.modified,
                 createdAt: d.createdAt, meta: d.meta };
      }),
    };
  }

  function deserialize(data) {
    if (!data || data.version !== "0518.1") {
      console.warn("[Workspace] deserialize: incompatible version or missing data");
      return;
    }
    _docs = [];
    _nextId = 1;
    data.docs.forEach(function(d) {
      var doc = _makeDoc(d.type, d.name, d.meta);
      doc.id        = d.id;
      doc.modified  = d.modified;
      doc.createdAt = d.createdAt;
      _docs.push(doc);
    });
    _activeId   = data.activeId;
    _sidebarCtx = data.sidebarCtx || "world";
    _emit("workspaceLoaded", { docs: _docs.slice(), activeId: _activeId });
    _emit("tabsChanged",     { docs: _docs.slice(), activeId: _activeId });
    _emit("sidebarContextChanged", { context: _sidebarCtx, prev: null });
  }

  // ── Default init ───────────────────────────────────────────────────────────
  // Creates the canonical first document — the live WOS route world.
  function initDefault() {
    if (_docs.length > 0) return;  // idempotent
    var world = createDocument("route", "WOS World", { isDefault: true });
    openDocument(world.id);
    RuntimeManager.register("routeWorld", { name: "routeWorld", active: true });
    RuntimeManager.attachToDocument(world.id, "routeWorld");
    console.log("[Workspace] initDefault — created default route document:", world.id);
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  SBE.Workspace = {
    // Document lifecycle
    createDocument:    createDocument,
    openDocument:      openDocument,
    closeDocument:     closeDocument,
    duplicateDocument: duplicateDocument,
    renameDocument:    renameDocument,
    reorderTab:        reorderTab,
    markModified:      markModified,
    markSaved:         markSaved,

    // Accessors
    getActiveDocument:  getActiveDocument,
    getAllDocuments:     getAllDocuments,
    getDocumentById:    getDocumentById,
    getDocTypes:        getDocTypes,
    getSidebarContexts: getSidebarContexts,

    // Sidebar
    setSidebarContext: setSidebarContext,
    getSidebarContext: getSidebarContext,

    // Runtime
    RuntimeManager: RuntimeManager,

    // Serialization
    serialize:   serialize,
    deserialize: deserialize,

    // Init
    initDefault: initDefault,

    // Events
    on:  on,
    off: off,
  };

})(window);
