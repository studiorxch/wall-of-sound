(function initWorkspaceUI(global) {
  "use strict";
  var SBE = (global.SBE = global.SBE || {});

  // ── Workspace UI (0518_WOS_WorkspaceArchitecture_v1.0.0) ─────────────────
  //
  // DOM manager. Injects and maintains three chrome surfaces:
  //
  //   #ws-tab-bar       — flex child, order:-1, inside .canvas-area
  //   #ws-sidebar-nav   — prepended to #left-rail, above existing buttons
  //   #ws-lower-panel   — flex child, inside .canvas-area, below canvas-wrap
  //
  // Responds to SBE.Workspace events: tabsChanged, activeDocumentChanged,
  // sidebarContextChanged. Never touches simulation state.

  // ── Sidebar nav definition ────────────────────────────────────────────────
  var NAV_ITEMS = [
    { ctx: "world",     icon: "◎", tooltip: "World" },
    { ctx: "layers",    icon: "▤", tooltip: "Layers" },
    { ctx: "sequences", icon: "⋮⋮", tooltip: "Sequences" },
    { ctx: "assets",    icon: "◻", tooltip: "Assets" },
    { ctx: "settings",  icon: "⚙", tooltip: "Settings" },
    { ctx: "help",      icon: "?", tooltip: "Help" },
  ];

  // ── DOM refs ──────────────────────────────────────────────────────────────
  var _tabBar      = null;
  var _sidebarNav  = null;
  var _lowerPanel  = null;
  var _navBtns     = {};   // ctx → button element

  // ── Init ──────────────────────────────────────────────────────────────────
  function init() {
    if (!SBE.Workspace) {
      console.warn("[WorkspaceUI] SBE.Workspace not available — skipping UI init");
      return;
    }

    _buildTabBar();
    _buildSidebarNav();
    _buildLowerPanel();

    // Mark canvas-area for padding overrides
    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) canvasArea.classList.add("ws-chrome-active");

    // Subscribe to workspace events
    SBE.Workspace.on("tabsChanged",            _onTabsChanged);
    SBE.Workspace.on("activeDocumentChanged",  _onActiveDocChanged);
    SBE.Workspace.on("sidebarContextChanged",  _onSidebarContextChanged);

    // Initial render
    _onTabsChanged({ docs: SBE.Workspace.getAllDocuments(), activeId: _getActiveId() });
    _onSidebarContextChanged({ context: SBE.Workspace.getSidebarContext() });
    _updateLowerPanel();

    console.log("[WorkspaceUI] initialized");
  }

  // ── Tab bar ───────────────────────────────────────────────────────────────
  function _buildTabBar() {
    _tabBar = document.createElement("div");
    _tabBar.id = "ws-tab-bar";

    // "New document" button at far right
    var addBtn = document.createElement("button");
    addBtn.className = "ws-tab-add";
    addBtn.title = "New document";
    addBtn.textContent = "+";
    addBtn.addEventListener("click", _onAddDocument);
    _tabBar.appendChild(addBtn);

    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) {
      canvasArea.insertBefore(_tabBar, canvasArea.firstChild);
    } else {
      console.warn("[WorkspaceUI] .canvas-area not found — tab bar not injected");
    }
  }

  function _onTabsChanged(evt) {
    if (!_tabBar) return;
    var docs     = evt.docs || [];
    var activeId = evt.activeId || null;

    // Clear existing tabs (keep the add button)
    var addBtn = _tabBar.querySelector(".ws-tab-add");
    _tabBar.innerHTML = "";

    // Render tabs
    docs.forEach(function(doc) {
      var tab = _makeTabEl(doc, activeId === doc.id);
      _tabBar.appendChild(tab);
    });

    // Re-append add button
    if (addBtn) _tabBar.appendChild(addBtn);

    // Scroll active tab into view
    var activeTab = _tabBar.querySelector(".ws-tab--active");
    if (activeTab) activeTab.scrollIntoView({ inline: "nearest", block: "nearest" });

    _updateLowerPanel();
  }

  function _makeTabEl(doc, isActive) {
    var tab = document.createElement("button");
    tab.className = "ws-tab" + (isActive ? " ws-tab--active" : "") +
                    (doc.modified ? " ws-tab--modified" : "");
    tab.style.setProperty("--ws-tab-accent", doc.accent);
    tab.dataset.docId = doc.id;
    tab.title = doc.name;

    // Icon
    var icon = document.createElement("span");
    icon.className = "ws-tab-icon";
    icon.textContent = doc.icon;

    // Label
    var label = document.createElement("span");
    label.className = "ws-tab-label";
    label.textContent = doc.name;

    // Modified dot
    var dot = document.createElement("span");
    dot.className = "ws-tab-modified";

    // Close
    var closeBtn = document.createElement("button");
    closeBtn.className = "ws-tab-close";
    closeBtn.textContent = "×";
    closeBtn.title = "Close";
    closeBtn.addEventListener("click", function(e) {
      e.stopPropagation();
      SBE.Workspace.closeDocument(doc.id);
    });

    tab.appendChild(icon);
    tab.appendChild(label);
    tab.appendChild(dot);
    tab.appendChild(closeBtn);

    tab.addEventListener("click", function(e) {
      // Don't activate if clicking close
      if (e.target === closeBtn) return;
      SBE.Workspace.openDocument(doc.id);
    });

    // Double-click to rename
    tab.addEventListener("dblclick", function(e) {
      if (e.target === closeBtn) return;
      _startRename(tab, doc);
    });

    return tab;
  }

  function _startRename(tabEl, doc) {
    var labelEl = tabEl.querySelector(".ws-tab-label");
    if (!labelEl) return;

    var input = document.createElement("input");
    input.type = "text";
    input.value = doc.name;
    input.style.cssText = [
      "background: rgba(255,255,255,0.08)",
      "border: 1px solid rgba(255,255,255,0.20)",
      "color: rgba(255,255,255,0.90)",
      "font-size: 11px",
      "font-family: inherit",
      "border-radius: 2px",
      "padding: 1px 4px",
      "outline: none",
      "width: 100px",
    ].join(";");

    tabEl.replaceChild(input, labelEl);
    input.select();

    function commit() {
      var val = input.value.trim();
      if (val) SBE.Workspace.renameDocument(doc.id, val);
      else     tabEl.replaceChild(labelEl, input);
    }
    input.addEventListener("keydown", function(e) {
      if (e.key === "Enter")  { e.preventDefault(); commit(); }
      if (e.key === "Escape") { tabEl.replaceChild(labelEl, input); }
    });
    input.addEventListener("blur", commit);
  }

  // ── Sidebar nav ───────────────────────────────────────────────────────────
  function _buildSidebarNav() {
    _sidebarNav = document.createElement("div");
    _sidebarNav.id = "ws-sidebar-nav";

    NAV_ITEMS.forEach(function(item) {
      var btn = document.createElement("button");
      btn.className = "ws-nav-btn";
      btn.dataset.ctx = item.ctx;
      btn.dataset.tooltip = item.tooltip;
      btn.title = item.tooltip;
      btn.textContent = item.icon;
      btn.addEventListener("click", function() {
        SBE.Workspace.setSidebarContext(item.ctx);
      });
      _sidebarNav.appendChild(btn);
      _navBtns[item.ctx] = btn;
    });

    var leftRail = document.getElementById("left-rail");
    if (leftRail) {
      leftRail.insertBefore(_sidebarNav, leftRail.firstChild);
    } else {
      console.warn("[WorkspaceUI] #left-rail not found — sidebar nav not injected");
    }
  }

  function _onSidebarContextChanged(evt) {
    var ctx = evt.context;
    Object.keys(_navBtns).forEach(function(key) {
      _navBtns[key].classList.toggle("ws-nav-btn--active", key === ctx);
    });
  }

  // ── Lower panel ───────────────────────────────────────────────────────────
  function _buildLowerPanel() {
    _lowerPanel = document.createElement("div");
    _lowerPanel.id = "ws-lower-panel";

    var canvasArea = document.querySelector(".canvas-area");
    if (canvasArea) {
      canvasArea.appendChild(_lowerPanel);
    } else {
      console.warn("[WorkspaceUI] .canvas-area not found — lower panel not injected");
    }
  }

  function _updateLowerPanel() {
    if (!_lowerPanel) return;
    _lowerPanel.innerHTML = "";

    var doc = SBE.Workspace ? SBE.Workspace.getActiveDocument() : null;
    var ctx = SBE.Workspace ? SBE.Workspace.getSidebarContext() : "—";

    // Accent dot
    var dot = document.createElement("div");
    dot.className = "ws-lower-accent-dot";
    dot.style.setProperty("--ws-lower-accent", doc ? doc.accent : "#3dd8c5");
    _lowerPanel.appendChild(dot);

    // Breadcrumb
    var crumb = document.createElement("div");
    crumb.className = "ws-lower-breadcrumb";

    var docSpan = document.createElement("span");
    docSpan.className = "ws-crumb-doc";
    docSpan.textContent = doc ? doc.name : "—";

    var sep = document.createElement("span");
    sep.className = "ws-crumb-sep";
    sep.textContent = "/";

    var ctxSpan = document.createElement("span");
    ctxSpan.className = "ws-crumb-ctx";
    ctxSpan.textContent = ctx;

    crumb.appendChild(docSpan);
    crumb.appendChild(sep);
    crumb.appendChild(ctxSpan);
    _lowerPanel.appendChild(crumb);

    // Status fields (right side)
    var status = document.createElement("div");
    status.className = "ws-lower-status";

    if (doc) {
      _addStatusField(status, "type", doc.type);
      var rtName = (doc.runtime && doc.runtime.name) ? doc.runtime.name : "—";
      _addStatusField(status, "rt", rtName);
    }

    var docCount = SBE.Workspace ? SBE.Workspace.getAllDocuments().length : 0;
    _addStatusField(status, "docs", String(docCount));

    _lowerPanel.appendChild(status);
  }

  function _addStatusField(container, key, value) {
    var field = document.createElement("div");
    field.className = "ws-lower-field";
    field.innerHTML = key + " <span class=\"ws-lower-value\">" + _esc(value) + "</span>";
    container.appendChild(field);
  }

  function _esc(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  // ── Event handlers ────────────────────────────────────────────────────────
  function _onActiveDocChanged() {
    _updateLowerPanel();
  }

  function _onAddDocument() {
    // Cycle through doc types for variety
    var types = Object.keys(SBE.Workspace.getDocTypes());
    var docs   = SBE.Workspace.getAllDocuments();
    var counts = {};
    types.forEach(function(t) { counts[t] = 0; });
    docs.forEach(function(d) { counts[d.type] = (counts[d.type] || 0) + 1; });
    // Create the least-represented type, defaulting to canvas
    var leastType = types.reduce(function(a, b) {
      return (counts[a] || 0) <= (counts[b] || 0) ? a : b;
    }, "canvas");
    var meta = SBE.Workspace.getDocTypes();
    var num  = (counts[leastType] || 0) + 1;
    var name = meta[leastType].label + " " + num;
    var doc = SBE.Workspace.createDocument(leastType, name);
    SBE.Workspace.openDocument(doc.id);
  }

  function _getActiveId() {
    var doc = SBE.Workspace ? SBE.Workspace.getActiveDocument() : null;
    return doc ? doc.id : null;
  }

  // ── Public API ─────────────────────────────────────────────────────────────
  SBE.WorkspaceUI = {
    init: init,
  };

})(window);
