// ── TraversalHUD v1.0.0 ────────────────────────────────────────────────────────
// 0529G_WOS_TraversalTelemetryAndTransportScaffold_v1.0.0
// Status: active
// Classification: observational-telemetry
//
// Purpose:
//   Read-only live overlay showing traversal telemetry.
//   Used to observe values before making preset decisions.
//   "Measure first. Preset later."
//
//   Shows: transport, destination, trip progress, elapsed/remaining time,
//          speed multiplier, current zoom/pitch/bearing, altitude.
//
// Authority:
//   READS ONLY: RegionalFlightTripRuntime, MapboxViewportRuntime,
//               RegionalFlightCameraRig, window._wos.nav (nav bar state)
//   MUST NOT: mutate any runtime, change traversal parameters, control UI
//
// Placement: wall/systems/presentation/traversalHUD.js
// Load: AFTER traversalControlDeck.js
//
// ──────────────────────────────────────────────────────────────────────────────
//
// ── Route Capability Audit (Part 7) ──────────────────────────────────────────
//
// FLIGHT
//   Source:     startGeneratedTrip — direct lat/lng interpolation
//   Capability: Any two global coordinates — no external API required
//   Limits:     Straight-line only (Mercator projection, not great circle arc)
//   Expansion:  Add intermediate waypoints to approximate great circle paths
//
// DRIVE
//   Source:     None currently implemented
//   Required:   Mapbox Directions API (profile: mapbox/driving)
//   Input:      Origin + destination coords → polyline route response
//   Expansion:  Fetch route, convert geometry to waypoints, feed startGeneratedTrip
//   Blocker:    None technical — needs Directions API token scope
//
// WALK
//   Source:     None currently implemented
//   Required:   Mapbox Directions API (profile: mapbox/walking)
//   Characteristics: Pedestrian paths, parks, crosswalks
//   Expansion:  Same pattern as Drive with walking profile
//   Blocker:    Same as Drive
//
// BIKE
//   Source:     None currently implemented
//   Required:   Mapbox Directions API (profile: mapbox/cycling)
//   Characteristics: Bike lanes, mixed cycling paths
//   Expansion:  Same pattern as Drive with cycling profile
//   Blocker:    Same as Drive
//
// TRANSIT
//   Source:     None — significantly more complex
//   Required:   GTFS schedule data + stop-based routing engine
//               OR Mapbox Matrix API (limited)
//   Complexity: High — requires real-time or scheduled departure data
//   Recommendation: Keep disabled until a transit data source is identified
//
// Summary: Drive/Walk/Bike all use the same Mapbox Directions API pattern.
// They share the same expansion path and could be built together once the
// API integration is in place. Transit is a separate problem.
//
// ──────────────────────────────────────────────────────────────────────────────
(function (global) {
  'use strict';

  var SBE     = (global.SBE = global.SBE || {});
  var VERSION = '1.0.0';

  var _el       = null;
  var _timer    = null;
  var _visible  = false;
  var UPDATE_MS = 500;

  // ── CSS ───────────────────────────────────────────────────────────────────────

  function _injectCSS() {
    if (document.getElementById('wos-hud-css')) return;
    var s = document.createElement('style');
    s.id  = 'wos-hud-css';
    s.textContent = [
      '#wos-hud {',
      '  position: fixed;',
      '  top: 14px; right: 14px;',
      '  z-index: 950;',
      '  background: rgba(4,5,7,0.88);',
      '  border: 1px solid rgba(255,255,255,0.08);',
      '  border-radius: 6px;',
      '  padding: 9px 12px 10px;',
      '  font-family: "SF Mono","Fira Mono",ui-monospace,monospace;',
      '  font-size: 10px;',
      '  line-height: 1.75;',
      '  color: rgba(255,255,255,0.55);',
      '  min-width: 150px;',
      '  backdrop-filter: blur(8px);',
      '  -webkit-backdrop-filter: blur(8px);',
      '  pointer-events: none;',
      '  white-space: pre;',
      '}',
      '#wos-hud.hud-hidden { display: none; }',
      '.hud-label {',
      '  font-size: 9px; letter-spacing: 0.10em; text-transform: uppercase;',
      '  color: rgba(255,255,255,0.22);',
      '}',
      '.hud-value { color: rgba(255,255,255,0.80); }',
      '.hud-dim   { color: rgba(255,255,255,0.30); }',
      '.hud-sep   {',
      '  border: none; border-top: 1px solid rgba(255,255,255,0.06);',
      '  margin: 5px 0; display: block;',
      '}',
      '.hud-row   { display: flex; justify-content: space-between; gap: 12px; }',
      '.hud-inactive { color: rgba(255,255,255,0.18); font-style: italic; }',
    ].join('\n');
    document.head.appendChild(s);
  }

  // ── Helpers ───────────────────────────────────────────────────────────────────

  function _fmtDuration(ms) {
    if (ms == null || ms < 0) return '—';
    var s   = Math.round(ms / 1000);
    var m   = Math.floor(s / 60);
    var sec = s % 60;
    if (m > 0) return m + 'm ' + String(sec).padStart(2, '0') + 's';
    return sec + 's';
  }

  function _fmtPct(v) {
    return (Math.round(v * 10) / 10).toFixed(1) + '%';
  }

  function _haversineKm(lat1, lng1, lat2, lng2) {
    var R    = 6371;
    var dLat = (lat2 - lat1) * Math.PI / 180;
    var dLng = (lng2 - lng1) * Math.PI / 180;
    var a    = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
               Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
               Math.sin(dLng / 2) * Math.sin(dLng / 2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  }

  function _fmtKm(km) {
    if (km == null) return '—';
    if (km >= 1000) return Math.round(km).toLocaleString() + ' km';
    return Math.round(km) + ' km';
  }

  // ── Data collection ───────────────────────────────────────────────────────────

  function _gather() {
    var rt  = global.SBE && SBE.RegionalFlightTripRuntime;
    var mvr = global.SBE && SBE.MapboxViewportRuntime;
    var nav = global._wos && global._wos.nav;  // set by traversalControlDeck on launch

    var rtState = rt && typeof rt.getState === 'function' ? rt.getState() : null;
    var map     = mvr && typeof mvr.getMap === 'function' ? mvr.getMap()  : null;

    // ── Trip ──────────────────────────────────────────────────────────────────
    var active    = !!(rtState && rtState.active);
    var progress  = active ? rtState.progressPct     : null;
    var simMs     = active ? rtState.elapsedMs       : null;   // SIM = simulated elapsed
    var durMs     = active ? rtState.durationMs      : null;
    var speedMult = (nav && nav.speedMult) ? nav.speedMult
                  : (active ? rtState.speedMultiplier : null);
    var tripPhase = active ? rtState.tripPhase       : null;

    // REAL = wall-clock time since launch
    var realMs = (nav && nav.launchRealMs) ? (Date.now() - nav.launchRealMs) : null;
    // REMAIN = remaining simulated time / speedMult → real time remaining
    var remainMs = (active && speedMult && durMs != null && simMs != null)
      ? (durMs - simMs) / speedMult : null;

    var curLat = active && rtState.current ? rtState.current.lat : null;
    var curLng = active && rtState.current ? rtState.current.lng : null;

    // ── Distance to destination ───────────────────────────────────────────────
    var distKm = null;
    if (curLat != null && nav && nav.toLoc) {
      distKm = _haversineKm(curLat, curLng, nav.toLoc.lat, nav.toLoc.lng);
    }

    // ── Camera ────────────────────────────────────────────────────────────────
    var zoom = null, pitch = null, bearing = null;
    if (map) {
      try { zoom    = Math.round(map.getZoom()    * 10) / 10; } catch (e) {}
      try { pitch   = Math.round(map.getPitch()   * 10) / 10; } catch (e) {}
      try { bearing = Math.round(((map.getBearing() % 360) + 360) % 360);  } catch (e) {}
    }

    // ── Actor / POV ───────────────────────────────────────────────────────────
    var altStep   = nav && nav.altStep ? nav.altStep : null;
    var transport = nav ? nav.transport : null;
    var toLabel   = nav ? nav.to        : null;

    return {
      active:    active,
      transport: transport,
      toLabel:   toLabel,
      progress:  progress,
      realMs:    realMs,      // REAL: wall-clock elapsed
      simMs:     simMs,       // SIM:  simulated elapsed
      remainMs:  remainMs,    // REMAIN: real time remaining
      durMs:     durMs,
      speedMult: speedMult,
      tripPhase: tripPhase,
      distKm:    distKm,
      zoom:      zoom,
      pitch:     pitch,
      bearing:   bearing,
      // Actor / POV
      actorType:          'aircraft',
      povType:            active ? 'forward' : null,
      actorAltitudeFt:    altStep ? altStep.altitudeFt : null,
      povAltitudeOffsetFt: 0,
    };
  }

  // ── Render ────────────────────────────────────────────────────────────────────

  function _render() {
    if (!_el || !_visible) return;

    var d = _gather();

    var lines = [];

    if (!d.active) {
      lines.push('<span class="hud-dim">no active trip</span>');
    } else {
      // Transport + destination
      var tLabel = (d.transport || 'flight').toUpperCase();
      var dest   = d.toLabel ? d.toLabel : '—';
      lines.push('<span class="hud-value">' + tLabel + '</span>'
               + '<span class="hud-dim">  › </span>'
               + '<span class="hud-value">' + dest + '</span>');

      lines.push('<hr class="hud-sep">');

      // Progress + remaining
      var pct     = d.progress != null ? _fmtPct(d.progress) : '—';
      var remain  = d.remainMs != null ? _fmtDuration(d.remainMs) : '—';
      var elapsed = d.elapsedMs != null ? _fmtDuration(d.elapsedMs) : '—';
      lines.push('<span class="hud-dim">PROGRESS  </span><span class="hud-value">' + pct + '</span>');
      lines.push('<span class="hud-dim">ELAPSED   </span><span class="hud-value">' + elapsed + '</span>');
      lines.push('<span class="hud-dim">REMAINING </span><span class="hud-value">' + remain + '</span>');

      if (d.distKm != null) {
        lines.push('<span class="hud-dim">DISTANCE  </span><span class="hud-value">' + _fmtKm(d.distKm) + '</span>');
      }

      lines.push('<hr class="hud-sep">');

      // Speed
      var spdX = d.speedMult != null ? d.speedMult + '×' : '—';
      lines.push('<span class="hud-dim">SPEED     </span><span class="hud-value">' + spdX + '</span>');

      if (d.tripPhase) {
        lines.push('<span class="hud-dim">PHASE     </span><span class="hud-value">' + d.tripPhase + '</span>');
      }

      lines.push('<hr class="hud-sep">');

      // Camera
      var zm  = d.zoom    != null ? d.zoom.toFixed(1)    : '—';
      var pt  = d.pitch   != null ? d.pitch.toFixed(1)   + '°' : '—';
      var brg = d.bearing != null ? Math.round((d.bearing + 360) % 360) + '°' : '—';
      lines.push('<span class="hud-dim">ZOOM      </span><span class="hud-value">' + zm + '</span>');
      lines.push('<span class="hud-dim">PITCH     </span><span class="hud-value">' + pt + '</span>');
      lines.push('<span class="hud-dim">BEARING   </span><span class="hud-value">' + brg + '</span>');
    }

    _el.innerHTML = lines.join('\n');
  }

  // ── Lifecycle ─────────────────────────────────────────────────────────────────

  function _createEl() {
    if (_el && _el.parentElement) return;
    _injectCSS();
    _el = document.createElement('div');
    _el.id = 'wos-hud';
    _el.className = 'hud-hidden';
    document.body.appendChild(_el);
  }

  function show() {
    _createEl();
    _visible = true;
    _el.classList.remove('hud-hidden');
    if (!_timer) {
      _render();
      _timer = global.setInterval(_render, UPDATE_MS);
    }
    console.log('[TraversalHUD] visible');
  }

  function hide() {
    _visible = false;
    if (_el) _el.classList.add('hud-hidden');
    if (_timer) { global.clearInterval(_timer); _timer = null; }
    console.log('[TraversalHUD] hidden');
  }

  function toggle() {
    _visible ? hide() : show();
  }

  // Auto-show when a trip becomes active, hide when idle.
  function _autoWatch() {
    var rt  = global.SBE && SBE.RegionalFlightTripRuntime;
    var was = _visible;
    if (rt && typeof rt.getState === 'function') {
      var s = rt.getState();
      if (s.active && !_visible) show();
    }
    global.setTimeout(_autoWatch, 1500);
  }

  // ── Debug state snapshot ──────────────────────────────────────────────────────

  function snapshot() {
    var d = _gather();
    console.group('[TraversalHUD] snapshot()');
    console.log('active   :', d.active);
    console.log('transport:', d.transport);
    console.log('to       :', d.toLabel);
    console.log('progress :', d.progress != null ? d.progress.toFixed(1) + '%' : '—');
    console.log('elapsed  :', d.elapsedMs != null ? _fmtDuration(d.elapsedMs) : '—');
    console.log('remain   :', d.remainMs  != null ? _fmtDuration(d.remainMs)  : '—');
    console.log('speedMult:', d.speedMult != null ? d.speedMult + 'x' : '—');
    console.log('distKm   :', d.distKm   != null ? _fmtKm(d.distKm) : '—');
    console.log('zoom     :', d.zoom);
    console.log('pitch    :', d.pitch);
    console.log('bearing  :', d.bearing);
    console.groupEnd();
    return d;
  }

  // ── Exports ───────────────────────────────────────────────────────────────────

  SBE.TraversalHUD = Object.freeze({
    VERSION:  VERSION,
    show:     show,
    hide:     hide,
    toggle:   toggle,
    snapshot: snapshot,
  });

  // ── Debug binding (retry guards) ──────────────────────────────────────────────

  var _debugObj = { show: show, hide: hide, toggle: toggle, snapshot: snapshot };

  function _bindDebug() {
    global._wos             = global._wos             || {};
    global._wos.debug       = global._wos.debug       || {};
    global._wos.debug.hud   = _debugObj;
  }
  _bindDebug();
  global.setTimeout(_bindDebug, 300);
  global.setTimeout(_bindDebug, 1000);
  global.setTimeout(_bindDebug, 2500);

  // ── Init ──────────────────────────────────────────────────────────────────────

  function _init() {
    _createEl();
    // Auto-watch: show HUD when a trip becomes active
    global.setTimeout(_autoWatch, 2000);
    console.log('[TraversalHUD] v' + VERSION + ' loaded — auto-shows on trip start');
    console.log('  _wos.debug.hud.toggle()   — show/hide');
    console.log('  _wos.debug.hud.snapshot() — read current values');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _init);
  } else {
    _init();
  }

})(window);
