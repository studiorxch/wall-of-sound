# wall/systems/transit

Transit (road-pivot) feed infrastructure for Wall of Sound.

## 0604G — MTA Bus Feed Source Inventory (inventory-only)

Establishes the bounded source contract for bringing **live MTA bus vehicle
positions** onto the Wall — **without** fetching, decoding, rendering, or
mutating `ActorRuntime`. This is the foundation the realtime adapter (0604H)
consumes.

### Files

| File | Exposes | Role |
|---|---|---|
| `mtaBusFeedConfig.js` | `SBE.MTABusFeedConfig` | Single bounded config: endpoints, cadence/stale/disabled constants, `apiKeyStorageKey`, failure-reason vocabulary. No secrets committed. |
| `mtaBusFeedSourceInventory.js` | `SBE.MTABusFeedSourceInventory` | Source list, primary-source accessor, local API-key plumbing, fetch-readiness contract. |

### Canonical source id

```
mta_bus_gtfs_rt_vehicle_positions
```

(Identifies the actual feed **category** — vehicle positions — not the broad
`mta_bus_gtfs_rt`.)

### Public API — `SBE.MTABusFeedSourceInventory`

```
start()                  // metadata registration only — no fetch
stop()
getState()
getSources()
getPrimarySource()
getSourceRegistryEntry()
getReadiness()           // { sourceRegistered, configured, apiKeyPresent,
                         //   vehiclePositionsUrlPresent, canAttemptFetch, lastError }
hasApiKey()
setApiKey(key)           // localStorage: wos.mtaBusTime.apiKey
clearApiKey()
maskedApiKey()           // "****abcd" — never the full secret
```

### Debug (`_wos.debug.worldActors`)

```
mtaBusFeedInventoryState()
mtaBusFeedSources()
mtaBusFeedReadiness()
mtaBusSetApiKey('<key>')   // prints masked confirmation only
mtaBusClearApiKey()
```

### API key handling

No key is ever committed or hardcoded. For local development, store it via the
runtime setter (`mtaBusSetApiKey`) which writes `localStorage['wos.mtaBusTime.apiKey']`,
or inject it through a backend env var if a GTFS-RT protobuf proxy is used.
Debug output is always masked (`****abcd`).

### Hard boundary (0604G)

Does **not**: fetch, decode protobuf, render, upsert to WSL, mutate
`ActorRuntime` / `ActorSourceRegistry` (frozen) / AIS, add Mapbox sources or
layers, change asset assignments, or touch any maritime module.

### Constants (baselines, not permanent doctrine)

```
MTA_BUS_REFRESH_CADENCE_MS = 15000
MTA_BUS_STALE_AFTER_MS     = 45000
MTA_BUS_DISABLED_AFTER_MS  = 180000
```

## 0604H — MTA Bus Realtime Adapter (fetch/decode only)

Fetches the GTFS-RT Vehicle Positions feed, decodes it, and exposes **raw bus
rows**. Creates no actors and renders nothing.

### Files

| File | Exposes | Role |
|---|---|---|
| `vendor/gtfsRealtimeBindings.js` | `SBE.GTFSRealtimeBindings` | Dependency-free minimal GTFS-Realtime protobuf decoder (`transit_realtime.FeedMessage.decode(bytes)`). Decodes only VehiclePosition fields; prefers a host binding if present. |
| `mtaBusRealtimeAdapter.js` | `SBE.MTABusRealtimeAdapter` | Readiness-gated fetch + decode → raw rows. |

### Public API — `SBE.MTABusRealtimeAdapter`

```
start({poll?})   // manual by default; poll:true uses config.refreshCadenceMs
stop()
isRunning()
fetchOnce()      // Promise<{ ok, rowsAdded, failureReason, decodedEntityCount, rejectedEntityCount }>
getState()
getRows()        // raw MtaBusRealtimeRow[] — no actor ids / no asset ids / no payloads
getStats()
clearRows()
setDebug(on)
```

### Raw row contract

```
{ sourceId:'mta_bus_gtfs_rt_vehicle_positions', vehicleId, tripId|null, routeId|null,
  latitude, longitude, bearing|null, speedMps|null, timestampUtcMs, occupancyStatus|null, rawEntityId }
```

### Debug (`_wos.debug.worldActors`)

```
mtaBusAdapterState()
mtaBusFetchOnce()     // returns the Promise; logs result (never prints the key)
mtaBusRows(limit)
mtaBusStats()
mtaBusClearRows()
```

### Manual proof

```
mtaBusSetApiKey('<key>') → mtaBusFeedReadiness() → mtaBusFetchOnce() → mtaBusRows(10) → mtaBusStats()
```
Raw live rows appear; no actors created; no buses visible.

### Failure reasons

Only `SBE.MTABusFeedConfig.FAILURE_REASONS` strings are used: readiness-false →
`not_configured`/`api_key_missing`, network exception → `network_error`, non-2xx →
`http_error`, 429 → `rate_limited`, decode throw → `decode_failed`, zero entities →
`empty_feed`, stale newest timestamp → `stale_feed`. Missing `routeId` is a
per-row warning/rejection count, never a whole-fetch failure.

### Hard boundary (0604H)

No actor creation, no ActorRuntime/TruthActorRuntime/WSL upserts, no Mapbox
sources/layers, no asset assignment, no styling/motion/viewport filtering, no
AIS/marine/Citi Bike/subway/Studio touch.

## 0604I — MTA Bus Actor Bridge (truth-only)

Converts adapter rows into canonical `vehicle.bus` truth actors via
`SBE.TruthActorRuntime.upsertActor`. The first point where live MTA bus data
becomes WOS world truth. Creates no render payloads, assigns no assets.

### File → `SBE.MTABusActorBridge`

```
start() / stop() / isActive()
syncFromAdapter()      // reads SBE.MTABusRealtimeAdapter.getRows()
syncRows(rows)         // → { ok, rows, accepted, rejected, actorCount }
getState() / getStats()
getActorIds()          // only bridge-created bus actor ids
clearBusActors()       // removes ONLY those ids (AIS/Citi Bike/debug untouched)
setEnabled(on) / setDebug(on)
```

### Actor upsert

`actorType: 'vehicle.bus'`, `sourceEntityId: vehicleId`, `ttlMs: MTA_BUS_STALE_AFTER_MS`
(45s), `label: 'MTA Bus ' + routeId` (→ `'MTA Bus'` when route null), metadata
`{ system:'mta', mode:'bus', routeId, tripId, vehicleId, occupancyStatus,
rawEntityId, sourceRowTimestampMs, truthClass:'observed', presentationEligible:true }`.

### Rejection vocabulary (bridge-local, distinct from feed FAILURE_REASONS)

`missing_vehicle_id · missing_coordinates · invalid_coordinates ·
invalid_timestamp · wrong_source_id · actor_runtime_unavailable ·
adapter_unavailable · upsert_failed · disabled`. Missing `routeId/tripId/bearing/
speed/occupancy` are **never** rejection causes.

### Debug (`_wos.debug.worldActors`)

```
mtaBusActorBridgeState() / mtaBusActorBridgeSync() / mtaBusActorBridgeStats()
mtaBusActorBridgeActors() / mtaBusActorBridgeClear() / mtaBusActorBridgeEnable(on)
```

### Truth vs presentation (important)

> Truth may be dense. Presentation must be selective.

The bridge writes **truth only** — it never calls WSL, ARA, the LOD policy,
Mapbox, or asset assignment itself. Whether a bus becomes *visible* is governed
entirely by the existing presentation pipeline (ActorRenderAuthority + LOD
policy), which today has **no `vehicle.bus` profile** — so buses stay
truth-only and unrendered until **0604J** introduces a bus visual fallback with
a visibility budget. The bridge tracks the actor ids it created so
`clearBusActors()` is precisely scoped.

### Manual proof

```
mtaBusSetApiKey('<key>') → mtaBusFetchOnce() → mtaBusRows()
→ mtaBusActorBridgeSync() → mtaBusActorBridgeState() → list()
```
`vehicle.bus` actors exist in TruthActorRuntime; no buses visible yet.

### Next

- `0604J_WOS_BusVisualFallbackRenderer_v1.0.0_BUILD` — select a bounded subset of
  `vehicle.bus` actors and render simple visible fallback shapes (with first-pass
  visibility budgeting — not all bus actors by default).
